from decimal import Decimal

from django.db import models
from django.db.models import Avg


class Vehicle(models.Model):
    ECONOMY, COMPACT, SEDAN, SUV, LUXURY, VAN, CONVERTIBLE = (
        "economy",
        "compact",
        "sedan",
        "suv",
        "luxury",
        "van",
        "convertible",
    )
    CATEGORY_CHOICES = [
        (ECONOMY, "Economy"),
        (COMPACT, "Compact"),
        (SEDAN, "Sedan"),
        (SUV, "SUV"),
        (LUXURY, "Luxury"),
        (VAN, "Van / minibus"),
        (CONVERTIBLE, "Convertible"),
    ]
    AUTOMATIC, MANUAL = "automatic", "manual"
    TRANSMISSION_CHOICES = [(AUTOMATIC, "Automatic"), (MANUAL, "Manual")]
    PETROL, DIESEL, HYBRID, ELECTRIC = "petrol", "diesel", "hybrid", "electric"
    FUEL_CHOICES = [(PETROL, "Petrol"), (DIESEL, "Diesel"), (HYBRID, "Hybrid"), (ELECTRIC, "Electric")]
    INSTANT, REQUEST = "instant", "request"
    MODE_CHOICES = [
        (INSTANT, "Instant booking"),
        (REQUEST, "Booking request (I approve each one)"),
    ]
    FLEXIBLE, MODERATE, STRICT = "flexible", "moderate", "strict"
    POLICY_CHOICES = [
        (FLEXIBLE, "Flexible: full refund up to 24h before pickup"),
        (MODERATE, "Moderate: full refund up to 3 days, half up to 24h"),
        (STRICT, "Strict: full refund up to 7 days, half up to 3 days"),
    ]
    PENDING, ACTIVE, PAUSED, REJECTED = "pending", "active", "paused", "rejected"
    STATUS_CHOICES = [
        (PENDING, "Awaiting approval"),
        (ACTIVE, "Live"),
        (PAUSED, "Paused"),
        (REJECTED, "Rejected"),
    ]

    partner = models.ForeignKey("accounts.Partner", on_delete=models.CASCADE, related_name="vehicles")
    city = models.ForeignKey("core.City", on_delete=models.PROTECT, related_name="vehicles")
    make = models.CharField(max_length=40)
    model = models.CharField(max_length=60)
    year = models.PositiveSmallIntegerField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default=ECONOMY, db_index=True)
    transmission = models.CharField(max_length=20, choices=TRANSMISSION_CHOICES, default=AUTOMATIC)
    fuel = models.CharField(max_length=20, choices=FUEL_CHOICES, default=PETROL)
    seats = models.PositiveSmallIntegerField(default=5)
    doors = models.PositiveSmallIntegerField(default=4)
    bags = models.PositiveSmallIntegerField(default=2, help_text="Suitcases that fit")
    air_conditioning = models.BooleanField(default=True)
    color = models.CharField(max_length=30, blank=True)
    plate_number = models.CharField(max_length=20, blank=True, help_text="Only visible to you and the platform")
    features = models.CharField(max_length=300, blank=True, help_text="Comma separated, e.g. Bluetooth, USB, Parking sensors")
    description = models.TextField(blank=True)

    daily_price = models.DecimalField(max_digits=8, decimal_places=2, help_text="USD per day")
    weekly_price = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True, help_text="USD for 7 days, optional")
    monthly_price = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True, help_text="USD for 30 days, optional")
    deposit = models.DecimalField(max_digits=8, decimal_places=2, default=Decimal("0.00"), help_text="Security deposit, held at pickup")

    mileage_limit_per_day = models.PositiveIntegerField(null=True, blank=True, help_text="km per day; empty means unlimited")
    extra_km_fee = models.DecimalField(max_digits=6, decimal_places=2, default=Decimal("0.00"), help_text="USD per extra km")
    insurance_included = models.BooleanField(default=True)
    insurance_details = models.CharField(max_length=300, blank=True, help_text="What is covered and the excess")
    min_driver_age = models.PositiveSmallIntegerField(default=21)
    min_license_years = models.PositiveSmallIntegerField(default=1)
    rental_conditions = models.TextField(blank=True, help_text="Fuel policy, smoking, borders, etc.")

    delivery_available = models.BooleanField(default=False)
    delivery_fee = models.DecimalField(max_digits=7, decimal_places=2, default=Decimal("0.00"), help_text="USD, one way")
    pickup_address = models.CharField(max_length=200, blank=True)
    pay_at_pickup = models.BooleanField(default=True, help_text="Let customers choose to pay you in person")

    booking_mode = models.CharField(max_length=20, choices=MODE_CHOICES, default=INSTANT)
    cancellation_policy = models.CharField(max_length=20, choices=POLICY_CHOICES, default=MODERATE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    @property
    def title(self):
        return f"{self.make} {self.model} {self.year}"

    @property
    def features_list(self):
        return [f.strip() for f in self.features.split(",") if f.strip()]

    @property
    def cover(self):
        photos = list(self.photos.all())
        for p in photos:
            if p.is_cover:
                return p
        return photos[0] if photos else None

    @property
    def is_bookable(self):
        return self.status == self.ACTIVE and self.partner.is_approved

    def rating(self):
        """(average, count) of reviews."""
        agg = self.reviews.aggregate(avg=Avg("rating"), n=models.Count("id"))
        return (round(agg["avg"], 1) if agg["avg"] else None, agg["n"])

    # --- pricing -----------------------------------------------------------------
    def _week_or_day(self, days):
        daily, weekly = self.daily_price, self.weekly_price
        best = daily * days
        if weekly:
            weeks, rem = divmod(days, 7)
            best = min(best, weekly * weeks + min(daily * rem, weekly))
        return best

    def price_for_days(self, days):
        """Cheapest combination of monthly, weekly and daily rates for this many days."""
        days = max(1, int(days))
        best = self._week_or_day(days)
        if self.monthly_price:
            months, rem = divmod(days, 30)
            best = min(best, self.monthly_price * months + min(self._week_or_day(rem), self.monthly_price))
        return best.quantize(Decimal("0.01"))


class VehiclePhoto(models.Model):
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="photos")
    image = models.ImageField(upload_to="vehicles/%Y/%m/")
    is_cover = models.BooleanField(default=False)
    position = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["-is_cover", "position", "id"]

    def __str__(self):
        return f"Photo {self.pk} of {self.vehicle}"


class BlockedPeriod(models.Model):
    """Dates a partner takes a vehicle off the market (service, personal use, offline rental)."""

    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="blocked_periods")
    start_at = models.DateTimeField()
    end_at = models.DateTimeField()
    reason = models.CharField(max_length=120, blank=True)

    class Meta:
        ordering = ["start_at"]

    def __str__(self):
        return f"{self.vehicle} blocked {self.start_at:%Y-%m-%d} to {self.end_at:%Y-%m-%d}"
