from django.contrib import admin

from .models import BlockedPeriod, Vehicle, VehiclePhoto


class PhotoInline(admin.TabularInline):
    model = VehiclePhoto
    extra = 0


class BlockInline(admin.TabularInline):
    model = BlockedPeriod
    extra = 0


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ("title", "partner", "city", "category", "daily_price", "booking_mode", "status")
    list_filter = ("status", "category", "booking_mode", "city", "transmission", "fuel")
    search_fields = ("make", "model", "plate_number", "partner__name")
    list_editable = ("status",)
    inlines = [PhotoInline, BlockInline]
