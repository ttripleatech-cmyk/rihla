from decimal import Decimal, InvalidOperation

from django.db.models import Avg, Count, F, Q

from apps.core.utils import parse_dt

from .models import Vehicle

SORTS = {
    "recommended": (F("featured").desc(), F("avg_rating").desc(nulls_last=True), "daily_price"),
    "price_asc": ("daily_price",),
    "price_desc": ("-daily_price",),
    "rating": (F("avg_rating").desc(nulls_last=True), "daily_price"),
    "newest": ("-created_at",),
}


def _decimal(value):
    try:
        return Decimal(value)
    except (InvalidOperation, TypeError):
        return None


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def search_vehicles(params):
    """Build the marketplace queryset from query-string style params (QueryDict or dict).

    Only live vehicles from approved partners are returned. When both `start` and
    `end` are given, vehicles that overlap a booking or blocked period are excluded.
    """
    from django.db.models import Case, IntegerField, Value, When

    from apps.bookings.services import unavailable_vehicle_ids

    qs = (
        Vehicle.objects.filter(status=Vehicle.ACTIVE, partner__status="approved")
        .select_related("partner", "city", "city__country")
        .prefetch_related("photos")
        .annotate(
            avg_rating=Avg("reviews__rating"),
            review_count=Count("reviews", distinct=True),
            featured=Case(
                When(partner__plan__featured_listings=True, then=Value(1)),
                default=Value(0),
                output_field=IntegerField(),
            ),
        )
    )

    if params.get("city"):
        qs = qs.filter(city__slug=params["city"])
    for field in ("category", "transmission", "fuel"):
        if params.get(field):
            qs = qs.filter(**{field: params[field]})
    if params.get("make"):
        qs = qs.filter(make__iexact=params["make"])
    seats = _int(params.get("seats"))
    if seats:
        qs = qs.filter(seats__gte=seats)
    low, high = _decimal(params.get("min_price")), _decimal(params.get("max_price"))
    if low is not None:
        qs = qs.filter(daily_price__gte=low)
    if high is not None:
        qs = qs.filter(daily_price__lte=high)
    if params.get("instant") in ("1", "true", "on"):
        qs = qs.filter(booking_mode=Vehicle.INSTANT)
    if params.get("partner_type") in ("company", "individual"):
        qs = qs.filter(partner__partner_type=params["partner_type"])
    if params.get("q"):
        text = params["q"].strip()
        qs = qs.filter(Q(make__icontains=text) | Q(model__icontains=text))

    start, end = parse_dt(params.get("start")), parse_dt(params.get("end"))
    if start and end and end > start:
        qs = qs.exclude(pk__in=unavailable_vehicle_ids(start, end))

    return qs.order_by(*SORTS.get(params.get("sort"), SORTS["recommended"]))
