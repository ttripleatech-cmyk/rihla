from django.conf import settings
from django.core.paginator import Paginator
from django.db.models import Avg
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.utils import timezone

from apps.bookings.models import Review
from apps.bookings.services import quote, rental_days, unavailable_ranges
from apps.core.models import City
from apps.core.utils import parse_dt

from .models import Vehicle
from .search import search_vehicles


def car_list(request):
    params = request.GET
    qs = search_vehicles(params)
    paginator = Paginator(qs, 9)
    page = paginator.get_page(params.get("page"))

    start, end = parse_dt(params.get("start")), parse_dt(params.get("end"))
    days = rental_days(start, end) if start and end and end > start else None
    cars = list(page.object_list)
    for car in cars:
        car.trip_total = car.price_for_days(days) if days else None

    map_points = []
    for car in cars:
        city = car.city
        if city.latitude is not None and city.longitude is not None:
            # Offset pins slightly by id so cars in one city do not stack exactly.
            jitter = ((car.pk * 37) % 100 - 50) / 5000
            map_points.append(
                {
                    "id": car.pk,
                    "title": car.title,
                    "price": str(car.daily_price),
                    "lat": float(city.latitude) + jitter,
                    "lng": float(city.longitude) - jitter,
                }
            )

    query = request.GET.copy()
    query.pop("page", None)
    query.pop("view", None)
    context = {
        "page": page,
        "cars": cars,
        "total": paginator.count,
        "days": days,
        "cities": City.objects.filter(country__is_active=True),
        "categories": Vehicle.CATEGORY_CHOICES,
        "transmissions": Vehicle.TRANSMISSION_CHOICES,
        "fuels": Vehicle.FUEL_CHOICES,
        "makes": Vehicle.objects.filter(status=Vehicle.ACTIVE).order_by("make").values_list("make", flat=True).distinct(),
        "params": params,
        "querystring": query.urlencode(),
        "view_mode": "map" if params.get("view") == "map" else "list",
        "map_points": map_points,
    }
    return render(request, "fleet/car_list.html", context)


def car_detail(request, pk):
    vehicle = get_object_or_404(
        Vehicle.objects.select_related("partner", "city", "city__country").prefetch_related("photos"),
        pk=pk,
    )
    is_owner = request.user.is_authenticated and vehicle.partner.owner_id == request.user.pk
    if not vehicle.is_bookable and not (is_owner or request.user.is_staff):
        raise Http404

    params = request.GET
    start, end = parse_dt(params.get("start")), parse_dt(params.get("end"))
    selected_extras = params.getlist("extras")
    delivery = params.get("delivery") == "1"
    current_quote = None
    quote_error = ""
    if start and end:
        if end <= start:
            quote_error = "Return time must be after pickup time."
        else:
            current_quote = quote(vehicle, start, end, selected_extras, delivery, params.get("promo", ""))

    reviews = Review.objects.filter(vehicle=vehicle).select_related("customer").order_by("-created_at")[:10]
    rating = vehicle.reviews.aggregate(avg=Avg("rating"))["avg"]
    context = {
        "vehicle": vehicle,
        "quote": current_quote,
        "quote_error": quote_error,
        "start": params.get("start", ""),
        "end": params.get("end", ""),
        "selected_extras": selected_extras,
        "delivery": delivery,
        "promo": params.get("promo", ""),
        "extras": settings.EXTRAS,
        "reviews": reviews,
        "avg_rating": round(rating, 1) if rating else None,
        "review_count": vehicle.reviews.count(),
        "busy": unavailable_ranges(vehicle),
        "now": timezone.localtime().strftime("%Y-%m-%dT%H:%M"),
        "is_owner": is_owner,
    }
    return render(request, "fleet/car_detail.html", context)
