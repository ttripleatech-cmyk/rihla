from django.urls import path

from . import views

app_name = "bookings"

urlpatterns = [
    path("", views.my_bookings, name="mine"),
    path("quote/", views.quote_json, name="quote"),
    path("checkout/<int:vehicle_id>/", views.checkout, name="checkout"),
    path("<str:ref>/", views.booking_detail, name="detail"),
    path("<str:ref>/pay/", views.pay, name="pay"),
    path("<str:ref>/cancel/", views.cancel, name="cancel"),
    path("<str:ref>/receipt/", views.receipt, name="receipt"),
    path("<str:ref>/review/", views.review, name="review"),
    path("<str:ref>/complaint/", views.complaint, name="complaint"),
]
