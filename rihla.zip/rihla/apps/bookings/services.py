"""Booking engine: pricing, availability, the booking lifecycle, refunds and commission.

All state changes go through these functions so the rules live in one place and are shared
by the website, the partner portal and the REST API.

Lifecycle
---------
Instant vehicle : pending_payment (hold, 15 min) -> confirmed -> active -> completed
Request vehicle : requested (24 h to answer) -> pending_payment (24 h to pay) -> confirmed ...
                  or declined / expired
Any open booking can be cancelled; refunds follow the vehicle's cancellation policy.

Double-booking protection
-------------------------
1. Every write that could create a conflict locks the Vehicle row (SELECT ... FOR UPDATE),
   expires stale holds, then re-checks availability inside the same transaction.
2. On PostgreSQL an exclusion constraint (see apps.py) rejects overlapping live bookings
   even if application code were bypassed.
"""
import math
from datetime import timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.conf import settings
from django.db import IntegrityError, transaction
from django.db.models import F, Q
from django.utils import timezone

from apps.core.audit import audit
from apps.core.models import PromoCode
from apps.core.notify import notify
from apps.fleet.models import BlockedPeriod, Vehicle

from .models import Booking, Payment
from .payments import get_gateway

CENT = Decimal("0.01")
ZERO = Decimal("0.00")


class BookingError(Exception):
    """A rule was broken. The message is safe to show to the user."""


def q(value):
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)


def rental_days(start, end):
    """Rental days are 24-hour blocks, rounded up, minimum one."""
    return max(1, math.ceil((end - start).total_seconds() / 86400))


# --- availability ----------------------------------------------------------------------
def blocking_q(now=None):
    """Bookings that currently occupy a vehicle (unpaid holds only while still valid)."""
    now = now or timezone.now()
    return (
        Q(status__in=[Booking.CONFIRMED, Booking.ACTIVE])
        | Q(status=Booking.PENDING_PAYMENT, hold_expires_at__gt=now)
        | Q(status=Booking.PENDING_PAYMENT, hold_expires_at__isnull=True)
    )


def unavailable_vehicle_ids(start, end):
    booked = Booking.objects.filter(blocking_q(), start_at__lt=end, end_at__gt=start).values_list("vehicle_id", flat=True)
    blocked = BlockedPeriod.objects.filter(start_at__lt=end, end_at__gt=start).values_list("vehicle_id", flat=True)
    return set(booked) | set(blocked)


def is_available(vehicle, start, end, exclude=None):
    bookings = Booking.objects.filter(blocking_q(), vehicle=vehicle, start_at__lt=end, end_at__gt=start)
    if exclude is not None:
        bookings = bookings.exclude(pk=exclude.pk)
    if bookings.exists():
        return False
    return not BlockedPeriod.objects.filter(vehicle=vehicle, start_at__lt=end, end_at__gt=start).exists()


def unavailable_ranges(vehicle):
    """Future occupied ranges, for the availability calendar on the vehicle page."""
    now = timezone.now()
    ranges = [
        {"start": b.start_at, "end": b.end_at, "kind": "booked"}
        for b in Booking.objects.filter(blocking_q(now), vehicle=vehicle, end_at__gt=now)
    ]
    ranges += [
        {"start": p.start_at, "end": p.end_at, "kind": "blocked"}
        for p in BlockedPeriod.objects.filter(vehicle=vehicle, end_at__gt=now)
    ]
    return sorted(ranges, key=lambda r: r["start"])


def expire_stale(now=None, vehicle=None):
    """Release unpaid holds and unanswered requests. Returns how many bookings expired."""
    now = now or timezone.now()
    qs = Booking.objects.filter(status__in=[Booking.PENDING_PAYMENT, Booking.REQUESTED], hold_expires_at__lt=now)
    if vehicle is not None:
        qs = qs.filter(vehicle=vehicle)
    return qs.update(status=Booking.EXPIRED)


# --- pricing ---------------------------------------------------------------------------
def quote(vehicle, start, end, extras=(), delivery=False, promo_code=""):
    """Price a rental. Pure calculation: nothing is saved."""
    days = rental_days(start, end)
    base = vehicle.price_for_days(days)

    chosen = [key for key in extras if key in settings.EXTRAS]
    extras_total = q(sum((settings.EXTRAS[k]["per_day"] * days for k in chosen), ZERO))
    delivery_fee = q(vehicle.delivery_fee) if (delivery and vehicle.delivery_available) else ZERO
    gross = base + extras_total + delivery_fee

    promo, promo_error, discount = None, "", ZERO
    code = (promo_code or "").strip()
    if code:
        promo = PromoCode.objects.filter(code__iexact=code).first()
        if promo is None:
            promo_error = "That promo code does not exist."
        else:
            promo_error = promo.check(days)
            if promo_error:
                promo = None
            else:
                discount = q(gross * promo.percent_off / 100)

    subtotal = gross - discount
    vat_rate = vehicle.city.country.vat_rate
    vat = q(subtotal * vat_rate / 100)
    total = subtotal + vat

    rate = vehicle.partner.effective_commission()
    commission = q(subtotal * rate / 100)
    return {
        "days": days,
        "base": base,
        "extras": chosen,
        "extras_total": extras_total,
        "delivery": bool(delivery_fee) or (delivery and vehicle.delivery_available),
        "delivery_fee": delivery_fee,
        "discount": discount,
        "promo": promo,
        "promo_error": promo_error,
        "subtotal": subtotal,
        "vat_rate": vat_rate,
        "vat": vat,
        "total": total,
        "deposit": q(vehicle.deposit),
        "commission_rate": rate,
        "commission": commission,
        "payout": subtotal - commission,
    }


def quote_to_json(data):
    """Serialise a quote for the JSON endpoints (Decimals become strings)."""
    out = {}
    for key, value in data.items():
        if key == "promo":
            out["promo"] = value.code if value else None
        elif isinstance(value, Decimal):
            out[key] = str(value)
        else:
            out[key] = value
    return out


def refund_percent(policy, start, now=None):
    """How much of the paid amount a customer gets back when cancelling `start`-dated booking."""
    now = now or timezone.now()
    hours = (start - now).total_seconds() / 3600
    if policy == Vehicle.FLEXIBLE:
        return 100 if hours >= 24 else 50
    if policy == Vehicle.MODERATE:
        return 100 if hours >= 72 else 50 if hours >= 24 else 0
    return 100 if hours >= 168 else 50 if hours >= 72 else 0  # strict


# --- lifecycle -------------------------------------------------------------------------
def create_booking(
    *,
    customer,
    vehicle,
    start,
    end,
    extras=(),
    delivery=False,
    delivery_address="",
    promo_code="",
    driver_name,
    driver_phone,
    notes="",
    allow_past=False,
):
    """Create an instant booking (held for payment) or a booking request."""
    now = timezone.now()
    if end <= start:
        raise BookingError("The return time must be after the pickup time.")
    if not allow_past and start < now - timedelta(minutes=5):
        raise BookingError("Pickup time is in the past.")
    if rental_days(start, end) > settings.MAX_RENTAL_DAYS:
        raise BookingError(f"Rentals are limited to {settings.MAX_RENTAL_DAYS} days. Contact us for longer terms.")
    if settings.REQUIRE_VERIFIED_EMAIL and not customer.email_verified:
        raise BookingError("Confirm your email address before booking.")

    try:
        with transaction.atomic():
            locked = (
                Vehicle.objects.select_for_update()
                .select_related("partner", "city", "city__country")
                .get(pk=vehicle.pk)
            )
            expire_stale(now, vehicle=locked)

            if not locked.is_bookable:
                raise BookingError("This vehicle is not available for booking.")
            if locked.partner.owner_id == customer.pk:
                raise BookingError("You cannot book your own vehicle.")
            if delivery and not locked.delivery_available:
                raise BookingError("This vehicle is pickup only.")
            if delivery and not delivery_address.strip():
                raise BookingError("Enter the address for delivery.")
            if not is_available(locked, start, end):
                raise BookingError("Sorry, these dates were just taken. Try different dates.")

            priced = quote(locked, start, end, extras, delivery, promo_code)
            if promo_code.strip() and priced["promo_error"]:
                raise BookingError(priced["promo_error"])

            instant = locked.booking_mode == Vehicle.INSTANT
            hold = timedelta(minutes=settings.INSTANT_HOLD_MINUTES) if instant else timedelta(hours=settings.REQUEST_RESPONSE_HOURS)
            booking = Booking.objects.create(
                vehicle=locked,
                partner=locked.partner,
                customer=customer,
                mode=Booking.INSTANT if instant else Booking.REQUEST,
                status=Booking.PENDING_PAYMENT if instant else Booking.REQUESTED,
                start_at=start,
                end_at=end,
                days=priced["days"],
                driver_name=driver_name,
                driver_phone=driver_phone,
                notes=notes,
                delivery_requested=bool(delivery),
                delivery_address=delivery_address.strip() if delivery else "",
                extras=priced["extras"],
                base_amount=priced["base"],
                extras_amount=priced["extras_total"],
                delivery_fee=priced["delivery_fee"],
                discount_amount=priced["discount"],
                subtotal=priced["subtotal"],
                vat_amount=priced["vat"],
                total=priced["total"],
                deposit=priced["deposit"],
                commission_rate=priced["commission_rate"],
                commission_amount=priced["commission"],
                partner_payout=priced["payout"],
                promo_code=priced["promo"],
                cancellation_policy=locked.cancellation_policy,
                hold_expires_at=now + hold,
            )
            if priced["promo"]:
                PromoCode.objects.filter(pk=priced["promo"].pk).update(times_used=F("times_used") + 1)
    except IntegrityError:
        # Raised by the PostgreSQL exclusion constraint if two requests raced past the checks.
        raise BookingError("Sorry, these dates were just taken. Try different dates.")

    audit(customer, "booking.created", booking, f"{booking.mode} {booking.start_at:%Y-%m-%d} to {booking.end_at:%Y-%m-%d}")
    if instant:
        notify(
            customer,
            f"Complete your booking {booking.reference}",
            f"Your {locked.title} is held for {settings.INSTANT_HOLD_MINUTES} minutes. "
            f"Pay ${booking.total} to confirm: {settings.SITE_URL}/bookings/{booking.reference}/pay/",
        )
    else:
        notify(
            locked.partner.owner,
            f"New booking request {booking.reference}",
            f"{customer.display_name} wants your {locked.title} from {booking.start_at:%d %b %H:%M} to "
            f"{booking.end_at:%d %b %H:%M}. Answer within {settings.REQUEST_RESPONSE_HOURS} hours in your partner portal.",
        )
        notify(customer, f"Request sent {booking.reference}", f"We sent your request for the {locked.title} to {locked.partner.name}. You will hear back within {settings.REQUEST_RESPONSE_HOURS} hours.")
    return booking


def pay_booking(booking, *, method, card_number="", holder=""):
    """Take payment for a held booking and confirm it."""
    with transaction.atomic():
        b = Booking.objects.select_for_update().select_related("vehicle", "partner", "customer").get(pk=booking.pk)
        if b.status != Booking.PENDING_PAYMENT:
            raise BookingError("This booking is not waiting for payment.")
        now = timezone.now()
        if b.hold_expires_at and b.hold_expires_at < now:
            b.status = Booking.EXPIRED
            b.save(update_fields=["status"])
            raise BookingError("The payment window has closed. Please search again.")

        if method == Payment.CASH:
            if not b.vehicle.pay_at_pickup:
                raise BookingError("This vehicle must be paid online.")
            Payment.objects.create(booking=b, method=Payment.CASH, amount=b.total, status=Payment.PENDING)
        else:
            result = get_gateway().charge(b.total, card_number=card_number, holder=holder, reference=b.reference)
            if not result.ok:
                raise BookingError(result.message or "Payment failed.")
            Payment.objects.create(
                booking=b, method=Payment.CARD, amount=b.total, status=Payment.SUCCEEDED, gateway_reference=result.reference
            )
        b.status = Booking.CONFIRMED
        b.confirmed_at = now
        b.hold_expires_at = None
        b.save(update_fields=["status", "confirmed_at", "hold_expires_at"])

    audit(b.customer, "booking.confirmed", b, f"payment={method}")
    notify(
        b.customer,
        f"Booking confirmed {b.reference}",
        f"Your {b.vehicle.title} is booked from {b.start_at:%d %b %H:%M} to {b.end_at:%d %b %H:%M}.\n"
        f"Total ${b.total} ({'pay at pickup' if method == Payment.CASH else 'paid online'}). Deposit at pickup: ${b.deposit}.",
    )
    notify(b.partner.owner, f"New confirmed booking {b.reference}", f"{b.driver_name} booked your {b.vehicle.title} for {b.days} day(s). Your payout: ${b.partner_payout}.")
    return b


def accept_request(booking, by_user):
    """Partner accepts a request. The customer then has time to pay; overlapping requests are declined."""
    declined = []
    try:
        with transaction.atomic():
            vehicle = Vehicle.objects.select_for_update().get(pk=booking.vehicle_id)
            expire_stale(vehicle=vehicle)
            b = Booking.objects.select_for_update().select_related("customer", "vehicle").get(pk=booking.pk)
            if b.status != Booking.REQUESTED:
                raise BookingError("This request is no longer open.")
            if not is_available(vehicle, b.start_at, b.end_at, exclude=b):
                raise BookingError("These dates are no longer free for this vehicle.")
            b.status = Booking.PENDING_PAYMENT
            b.hold_expires_at = timezone.now() + timedelta(hours=settings.REQUEST_PAYMENT_HOURS)
            b.save(update_fields=["status", "hold_expires_at"])

            overlapping = Booking.objects.filter(
                vehicle=vehicle, status=Booking.REQUESTED, start_at__lt=b.end_at, end_at__gt=b.start_at
            ).exclude(pk=b.pk)
            declined = list(overlapping.select_related("customer"))
            overlapping.update(status=Booking.DECLINED, decline_reason="The vehicle was booked by another customer for these dates.")
    except IntegrityError:
        raise BookingError("These dates are no longer free for this vehicle.")

    audit(by_user, "booking.request_accepted", b)
    notify(
        b.customer,
        f"Request accepted {b.reference}",
        f"Good news: {b.vehicle.title} is yours if you pay within {settings.REQUEST_PAYMENT_HOURS} hours: {settings.SITE_URL}/bookings/{b.reference}/pay/",
    )
    for other in declined:
        notify(other.customer, f"Request declined {other.reference}", "Sorry, the vehicle was booked by someone else for those dates. Please search for another car.")
    return b


def decline_request(booking, by_user, reason=""):
    with transaction.atomic():
        b = Booking.objects.select_for_update().select_related("customer", "vehicle").get(pk=booking.pk)
        if b.status != Booking.REQUESTED:
            raise BookingError("This request is no longer open.")
        b.status = Booking.DECLINED
        b.decline_reason = reason[:300]
        b.save(update_fields=["status", "decline_reason"])
    audit(by_user, "booking.request_declined", b, reason)
    notify(b.customer, f"Request declined {b.reference}", f"The owner could not accept your request for the {b.vehicle.title}. {reason}\nPlease try another car.")
    return b


def cancel_booking(booking, by_user, reason=""):
    """Cancel an open booking and refund according to who cancels and the policy."""
    with transaction.atomic():
        b = Booking.objects.select_for_update().select_related("customer", "vehicle", "partner").get(pk=booking.pk)
        if not b.can_cancel:
            raise BookingError("This booking can no longer be cancelled.")
        now = timezone.now()
        by_customer = by_user.pk == b.customer_id
        paid = b.amount_paid
        percent = 100
        if b.status == Booking.CONFIRMED and by_customer:
            percent = refund_percent(b.cancellation_policy, b.start_at, now)
        refund = q(paid * percent / 100) if paid > 0 else ZERO

        if refund > 0:
            original = b.payments.filter(kind=Payment.CHARGE, status=Payment.SUCCEEDED, method=Payment.CARD).first()
            result = get_gateway().refund(refund, original_reference=original.gateway_reference if original else "")
            if not result.ok:
                raise BookingError("The refund could not be processed. Please contact support.")
            Payment.objects.create(
                booking=b, kind=Payment.REFUND, method=Payment.CARD, amount=refund, status=Payment.SUCCEEDED, gateway_reference=result.reference
            )
        # A cash booking that was never collected has nothing to refund; mark the placeholder as failed.
        b.payments.filter(method=Payment.CASH, status=Payment.PENDING).update(status=Payment.FAILED)

        b.status = Booking.CANCELLED
        b.cancelled_at = now
        b.cancelled_by = by_user
        b.cancel_reason = reason[:300]
        b.refund_amount = refund
        b.hold_expires_at = None
        b.save(update_fields=["status", "cancelled_at", "cancelled_by", "cancel_reason", "refund_amount", "hold_expires_at"])

    audit(by_user, "booking.cancelled", b, f"refund=${refund} ({percent}%) {reason}")
    notify(b.customer, f"Booking cancelled {b.reference}", f"Your booking was cancelled. Refund: ${refund}.")
    if not by_customer:
        return b
    notify(b.partner.owner, f"Booking cancelled {b.reference}", f"{b.driver_name} cancelled the booking of your {b.vehicle.title}. The dates are free again.")
    return b


def start_rental(booking, by_user):
    with transaction.atomic():
        b = Booking.objects.select_for_update().get(pk=booking.pk)
        if b.status != Booking.CONFIRMED:
            raise BookingError("Only confirmed bookings can be handed over.")
        b.status = Booking.ACTIVE
        b.save(update_fields=["status"])
        # Cash is collected by the partner at handover.
        b.payments.filter(method=Payment.CASH, status=Payment.PENDING).update(status=Payment.SUCCEEDED)
    audit(by_user, "booking.started", b)
    return b


def complete_rental(booking, by_user):
    with transaction.atomic():
        b = Booking.objects.select_for_update().select_related("customer", "vehicle").get(pk=booking.pk)
        if b.status != Booking.ACTIVE:
            raise BookingError("Only rentals on the road can be completed.")
        b.status = Booking.COMPLETED
        b.completed_at = timezone.now()
        b.save(update_fields=["status", "completed_at"])
    audit(by_user, "booking.completed", b)
    notify(b.customer, f"How was your {b.vehicle.title}?", f"Thanks for renting with Rihla. Leave a review: {settings.SITE_URL}/bookings/{b.reference}/review/")
    return b
