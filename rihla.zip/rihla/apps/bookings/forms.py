import re

from django import forms

from .models import Complaint, Payment, Review


class CheckoutForm(forms.Form):
    driver_name = forms.CharField(label="Driver's full name", max_length=120)
    driver_phone = forms.CharField(label="Phone (WhatsApp if possible)", max_length=30)
    delivery_address = forms.CharField(label="Delivery address", max_length=200, required=False)
    notes = forms.CharField(label="Notes for the owner", widget=forms.Textarea(attrs={"rows": 3}), required=False)
    accept_terms = forms.BooleanField(label="I have read the rental conditions and the cancellation policy")


class PayForm(forms.Form):
    method = forms.ChoiceField(choices=Payment.METHOD_CHOICES, initial=Payment.CARD, widget=forms.RadioSelect)
    holder = forms.CharField(label="Name on card", required=False, max_length=80)
    card_number = forms.CharField(label="Card number", required=False, max_length=23, widget=forms.TextInput(attrs={"inputmode": "numeric", "autocomplete": "cc-number"}))
    expiry = forms.CharField(label="Expiry (MM/YY)", required=False, max_length=5, widget=forms.TextInput(attrs={"autocomplete": "cc-exp"}))
    cvc = forms.CharField(label="CVC", required=False, max_length=4, widget=forms.PasswordInput(attrs={"autocomplete": "cc-csc"}))

    def __init__(self, *args, allow_cash=True, **kwargs):
        super().__init__(*args, **kwargs)
        if not allow_cash:
            self.fields["method"].choices = [(Payment.CARD, "Card (online)")]

    def clean(self):
        data = super().clean()
        if data.get("method") == Payment.CARD:
            digits = re.sub(r"\D", "", data.get("card_number", ""))
            if not 13 <= len(digits) <= 19:
                self.add_error("card_number", "Enter a valid card number.")
            if not re.fullmatch(r"\d{2}/\d{2}", data.get("expiry", "")):
                self.add_error("expiry", "Use the format MM/YY.")
            if not re.fullmatch(r"\d{3,4}", data.get("cvc", "")):
                self.add_error("cvc", "Enter the 3 or 4 digit code.")
            if not data.get("holder"):
                self.add_error("holder", "Enter the name on the card.")
        return data


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ["rating", "comment"]
        widgets = {"comment": forms.Textarea(attrs={"rows": 4}), "rating": forms.RadioSelect}


class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ["subject", "message"]
        widgets = {"message": forms.Textarea(attrs={"rows": 5})}
