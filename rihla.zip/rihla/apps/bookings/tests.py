"""Tests for the booking engine, the main pages and the API.

Run with:  python manage.py test
"""
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from apps.accounts.models import Partner
from apps.bookings import services
from apps.bookings.models import Booking, Payment
from apps.bookings.services import BookingError
from apps.core.models import City, Country, PromoCode
from apps.fleet.models import BlockedPeriod, Vehicle
from apps.fleet.search import search_vehicles

User = get_user_model()
PASSWORD = "pw-Strong-12345"


def make_user(email, **extra):
    return User.objects.create_user(username=email, email=email, password=PASSWORD, first_name=email.split("@")[0], email_verified=True, **extra)


def make_world(mode="instant", policy="moderate", commission="15"):
    lebanon = Country.objects.create(code="LB", name="Lebanon", currency="USD", vat_rate=Decimal("11"))
    city = City.objects.create(country=lebanon, name="Beirut", slug="beirut", latitude=Decimal("33.89"), longitude=Decimal("35.50"), is_featured=True)
    owner = make_user("owner@test.example", role="partner")
    partner = Partner.objects.create(
        owner=owner, partner_type="company", name="Test Rentals", city=city, phone="123", status="approved", verified=True,
        commission_override=Decimal(commission),
    )
    vehicle = Vehicle.objects.create(
        partner=partner, city=city, make="Kia", model="Picanto", year=2023, daily_price=Decimal("30"), weekly_price=Decimal("180"),
        monthly_price=Decimal("600"), deposit=Decimal("100"), booking_mode=mode, cancellation_policy=policy, status="active",
        delivery_available=True, delivery_fee=Decimal("10"),
    )
    return {"city": city, "owner": owner, "partner": partner, "vehicle": vehicle}


def at(days=0, hours=0):
    base = timezone.now().replace(minute=0, second=0, microsecond=0)
    return base + timedelta(days=days, hours=hours)


def book(world, customer, start, end, **kwargs):
    return services.create_booking(
        customer=customer, vehicle=world["vehicle"], start=start, end=end, driver_name="Test Driver", driver_phone="1", **kwargs
    )


class PricingTests(TestCase):
    def setUp(self):
        self.vehicle = make_world()["vehicle"]

    def test_tiered_pricing_picks_cheapest_combination(self):
        expected = {1: 30, 3: 90, 6: 180, 7: 180, 8: 210, 14: 360, 30: 600, 31: 630, 45: 990}
        for days, price in expected.items():
            self.assertEqual(self.vehicle.price_for_days(days), Decimal(price), f"{days} days")

    def test_quote_breakdown_vat_and_commission(self):
        q = services.quote(self.vehicle, at(1), at(3))
        self.assertEqual(q["days"], 2)
        self.assertEqual(q["base"], Decimal("60.00"))
        self.assertEqual(q["vat"], Decimal("6.60"))
        self.assertEqual(q["total"], Decimal("66.60"))
        self.assertEqual(q["commission"], Decimal("9.00"))
        self.assertEqual(q["payout"], Decimal("51.00"))

    def test_extras_delivery_and_promo(self):
        PromoCode.objects.create(code="TEN", percent_off=Decimal("10"))
        q = services.quote(self.vehicle, at(1), at(3), extras=["gps", "unknown"], delivery=True, promo_code="ten")
        self.assertEqual(q["extras_total"], Decimal("8.00"))  # gps $4 x 2 days; unknown extra ignored
        self.assertEqual(q["delivery_fee"], Decimal("10.00"))
        self.assertEqual(q["discount"], Decimal("7.80"))  # 10% of 78
        self.assertEqual(q["subtotal"], Decimal("70.20"))

    def test_bad_promo_is_reported(self):
        q = services.quote(self.vehicle, at(1), at(3), promo_code="NOPE")
        self.assertTrue(q["promo_error"])
        self.assertEqual(q["discount"], Decimal("0.00"))


class AvailabilityTests(TestCase):
    def setUp(self):
        self.world = make_world()
        self.a = make_user("a@test.example")
        self.b = make_user("b@test.example")

    def test_overlapping_booking_is_rejected(self):
        book(self.world, self.a, at(2), at(5))
        with self.assertRaises(BookingError):
            book(self.world, self.b, at(4), at(7))
        with self.assertRaises(BookingError):
            book(self.world, self.b, at(1), at(3))
        with self.assertRaises(BookingError):
            book(self.world, self.b, at(3), at(4))  # fully inside

    def test_back_to_back_bookings_are_allowed(self):
        book(self.world, self.a, at(2), at(5))
        book(self.world, self.b, at(5), at(7))  # starts exactly when the first ends

    def test_blocked_period_makes_vehicle_unavailable(self):
        BlockedPeriod.objects.create(vehicle=self.world["vehicle"], start_at=at(2), end_at=at(4))
        with self.assertRaises(BookingError):
            book(self.world, self.a, at(3), at(5))
        self.assertNotIn(self.world["vehicle"].pk, [v.pk for v in search_vehicles({"start": at(3).isoformat(), "end": at(5).isoformat()})])
        self.assertIn(self.world["vehicle"].pk, [v.pk for v in search_vehicles({"start": at(6).isoformat(), "end": at(8).isoformat()})])

    def test_expired_hold_frees_the_vehicle(self):
        held = book(self.world, self.a, at(2), at(5))
        Booking.objects.filter(pk=held.pk).update(hold_expires_at=timezone.now() - timedelta(minutes=1))
        book(self.world, self.b, at(2), at(5))  # succeeds because the unpaid hold lapsed
        held.refresh_from_db()
        self.assertEqual(held.status, Booking.EXPIRED)

    def test_cannot_book_own_vehicle(self):
        with self.assertRaises(BookingError):
            book(self.world, self.world["owner"], at(2), at(3))

    def test_past_and_inverted_dates_rejected(self):
        with self.assertRaises(BookingError):
            book(self.world, self.a, at(-3), at(-1))
        with self.assertRaises(BookingError):
            book(self.world, self.a, at(3), at(2))

    def test_unapproved_partner_vehicle_is_not_bookable(self):
        Partner.objects.filter(pk=self.world["partner"].pk).update(status="suspended")
        with self.assertRaises(BookingError):
            book(self.world, self.a, at(2), at(3))


class LifecycleTests(TestCase):
    def setUp(self):
        self.world = make_world()
        self.customer = make_user("c@test.example")

    def pay(self, booking):
        return services.pay_booking(booking, method=Payment.CARD, card_number="4111111111111111", holder="Test")

    def test_instant_booking_pay_confirm_complete(self):
        booking = book(self.world, self.customer, at(2), at(4))
        self.assertEqual(booking.status, Booking.PENDING_PAYMENT)
        booking = self.pay(booking)
        self.assertEqual(booking.status, Booking.CONFIRMED)
        self.assertEqual(booking.amount_paid, booking.total)
        booking = services.start_rental(booking, self.world["owner"])
        booking = services.complete_rental(booking, self.world["owner"])
        self.assertEqual(booking.status, Booking.COMPLETED)

    def test_declined_card_does_not_confirm(self):
        booking = book(self.world, self.customer, at(2), at(4))
        with self.assertRaises(BookingError):
            services.pay_booking(booking, method=Payment.CARD, card_number="4000000000000002", holder="Test")
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.PENDING_PAYMENT)

    def test_cash_booking_is_confirmed_and_collected_at_pickup(self):
        booking = services.pay_booking(book(self.world, self.customer, at(2), at(4)), method=Payment.CASH)
        self.assertEqual(booking.status, Booking.CONFIRMED)
        self.assertEqual(booking.amount_paid, Decimal("0.00"))
        services.start_rental(booking, self.world["owner"])
        booking.refresh_from_db()
        self.assertEqual(booking.amount_paid, booking.total)

    def test_cannot_pay_twice(self):
        booking = self.pay(book(self.world, self.customer, at(2), at(4)))
        with self.assertRaises(BookingError):
            self.pay(booking)

    def test_moderate_policy_refunds(self):
        far = self.pay(book(self.world, self.customer, at(10), at(12)))
        far = services.cancel_booking(far, self.customer)
        self.assertEqual(far.refund_amount, far.total)  # 100% when 3+ days away

        near = self.pay(book(self.world, self.customer, at(1, 6), at(3)))  # about 30 hours away
        near = services.cancel_booking(near, self.customer)
        self.assertEqual(near.refund_amount, (near.total / 2).quantize(Decimal("0.01")))

        late = self.pay(book(self.world, self.customer, at(0, 5), at(2)))  # about 5 hours away
        late = services.cancel_booking(late, self.customer)
        self.assertEqual(late.refund_amount, Decimal("0.00"))

    def test_partner_cancellation_always_refunds_in_full(self):
        late = self.pay(book(self.world, self.customer, at(0, 5), at(2)))
        late = services.cancel_booking(late, self.world["owner"], "Car broke down")
        self.assertEqual(late.refund_amount, late.total)
        self.assertEqual(late.amount_paid, Decimal("0.00"))

    def test_cancelled_booking_frees_dates(self):
        first = book(self.world, self.customer, at(2), at(5))
        services.cancel_booking(first, self.customer)
        book(self.world, make_user("d@test.example"), at(2), at(5))

    def test_refund_percent_table(self):
        now = timezone.now()
        self.assertEqual(services.refund_percent("flexible", now + timedelta(hours=30), now), 100)
        self.assertEqual(services.refund_percent("flexible", now + timedelta(hours=5), now), 50)
        self.assertEqual(services.refund_percent("strict", now + timedelta(days=8), now), 100)
        self.assertEqual(services.refund_percent("strict", now + timedelta(days=4), now), 50)
        self.assertEqual(services.refund_percent("strict", now + timedelta(days=1), now), 0)

    def test_commission_is_frozen_on_the_booking(self):
        booking = book(self.world, self.customer, at(2), at(4))
        Partner.objects.filter(pk=self.world["partner"].pk).update(commission_override=Decimal("50"))
        booking.refresh_from_db()
        self.assertEqual(booking.commission_rate, Decimal("15.00"))


class RequestFlowTests(TestCase):
    def setUp(self):
        self.world = make_world(mode="request")
        self.first = make_user("first@test.example")
        self.second = make_user("second@test.example")

    def test_requests_do_not_block_until_accepted(self):
        r1 = book(self.world, self.first, at(2), at(5))
        r2 = book(self.world, self.second, at(3), at(6))
        self.assertEqual((r1.status, r2.status), (Booking.REQUESTED, Booking.REQUESTED))

    def test_accepting_declines_overlapping_requests(self):
        r1 = book(self.world, self.first, at(2), at(5))
        r2 = book(self.world, self.second, at(3), at(6))
        r3 = book(self.world, self.second, at(8), at(9))  # does not overlap
        services.accept_request(r1, self.world["owner"])
        for b in (r1, r2, r3):
            b.refresh_from_db()
        self.assertEqual(r1.status, Booking.PENDING_PAYMENT)
        self.assertEqual(r2.status, Booking.DECLINED)
        self.assertEqual(r3.status, Booking.REQUESTED)
        with self.assertRaises(BookingError):
            services.accept_request(r2, self.world["owner"])

    def test_accepted_request_then_blocks_new_bookings(self):
        r1 = book(self.world, self.first, at(2), at(5))
        services.accept_request(r1, self.world["owner"])
        with self.assertRaises(BookingError):
            book(self.world, self.second, at(3), at(4))

    def test_decline_request(self):
        r1 = book(self.world, self.first, at(2), at(5))
        r1 = services.decline_request(r1, self.world["owner"], "Not available")
        self.assertEqual(r1.status, Booking.DECLINED)

    def test_unanswered_request_expires(self):
        r1 = book(self.world, self.first, at(2), at(5))
        Booking.objects.filter(pk=r1.pk).update(hold_expires_at=timezone.now() - timedelta(minutes=1))
        self.assertEqual(services.expire_stale(), 1)
        r1.refresh_from_db()
        self.assertEqual(r1.status, Booking.EXPIRED)


class PageTests(TestCase):
    def setUp(self):
        self.world = make_world()
        self.customer = make_user("page@test.example")

    def test_public_pages_render(self):
        for name in ("home", "partners", "how_it_works", "terms", "healthz", "fleet:list", "accounts:login", "accounts:register"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
        self.assertEqual(self.client.get(reverse("fleet:list") + "?view=map&city=beirut").status_code, 200)
        self.assertEqual(self.client.get(reverse("fleet:detail", args=[self.world["vehicle"].pk])).status_code, 200)

    def test_detail_with_quote_renders(self):
        url = reverse("fleet:detail", args=[self.world["vehicle"].pk])
        response = self.client.get(url, {"start": at(2).strftime("%Y-%m-%dT%H:%M"), "end": at(4).strftime("%Y-%m-%dT%H:%M"), "extras": ["gps"]})
        self.assertContains(response, "Total")

    def test_checkout_requires_login(self):
        response = self.client.get(reverse("bookings:checkout", args=[self.world["vehicle"].pk]))
        self.assertEqual(response.status_code, 302)
        self.assertIn("/accounts/login/", response["Location"])

    def test_full_booking_flow_through_the_website(self):
        self.client.login(username="page@test.example", password=PASSWORD)
        params = {"start": at(2).strftime("%Y-%m-%dT%H:%M"), "end": at(4).strftime("%Y-%m-%dT%H:%M")}
        url = reverse("bookings:checkout", args=[self.world["vehicle"].pk])
        self.assertEqual(self.client.get(url, params).status_code, 200)
        response = self.client.post(url, {**params, "driver_name": "Page Tester", "driver_phone": "555", "accept_terms": "on"})
        booking = Booking.objects.get(customer=self.customer)
        self.assertRedirects(response, reverse("bookings:pay", args=[booking.reference]))
        pay = self.client.post(reverse("bookings:pay", args=[booking.reference]), {"method": "card", "holder": "Page Tester", "card_number": "4111 1111 1111 1111", "expiry": "12/30", "cvc": "123"})
        self.assertRedirects(pay, reverse("bookings:detail", args=[booking.reference]))
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.CONFIRMED)
        for name in ("bookings:detail", "bookings:receipt"):
            self.assertEqual(self.client.get(reverse(name, args=[booking.reference])).status_code, 200)
        self.assertEqual(self.client.get(reverse("bookings:mine")).status_code, 200)

    def test_booking_is_private_to_its_parties(self):
        booking = book(self.world, self.customer, at(2), at(3))
        stranger = make_user("stranger@test.example")
        self.client.login(username="stranger@test.example", password=PASSWORD)
        self.assertEqual(self.client.get(reverse("bookings:detail", args=[booking.reference])).status_code, 403)
        self.assertEqual(self.client.post(reverse("bookings:cancel", args=[booking.reference])).status_code, 403)
        self.assertEqual(self.client.get(reverse("accounts:secure_file", args=["license", self.customer.pk])).status_code, 403)

    def test_quote_endpoint(self):
        response = self.client.get(reverse("bookings:quote"), {"vehicle": self.world["vehicle"].pk, "start": at(2).isoformat(), "end": at(4).isoformat()})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["total"], "66.60")
        self.assertTrue(response.json()["available"])

    def test_partner_portal_and_admin_dashboard(self):
        booking = book(self.world, self.customer, at(2), at(3))
        self.client.login(username="owner@test.example", password=PASSWORD)
        for name in ("partner:home", "partner:vehicles", "partner:vehicle_new", "partner:bookings", "partner:documents", "partner:plans"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
        self.assertEqual(self.client.get(reverse("partner:vehicle_edit", args=[self.world["vehicle"].pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse("manage:home")).status_code, 403)  # partners are not staff

        staff = make_user("staff@test.example")
        staff.is_staff = True
        staff.save()
        self.client.login(username="staff@test.example", password=PASSWORD)
        for name in ("manage:home", "manage:partners", "manage:vehicles", "manage:bookings", "manage:complaints", "manage:audit", "manage:report_csv"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
        self.assertEqual(self.client.get(reverse("partner:home")).status_code, 302)  # staff without a partner profile

    def test_customer_cannot_use_partner_portal(self):
        self.client.login(username="page@test.example", password=PASSWORD)
        self.assertEqual(self.client.get(reverse("partner:home")).status_code, 302)


class ApiTests(TestCase):
    def setUp(self):
        self.world = make_world()
        self.customer = make_user("api@test.example")

    def test_vehicle_list_and_detail_are_public(self):
        data = self.client.get("/api/v1/vehicles/").json()
        self.assertEqual(data["count"], 1)
        self.assertEqual(data["results"][0]["title"], "Kia Picanto 2023")
        self.assertEqual(self.client.get(f"/api/v1/vehicles/{self.world['vehicle'].pk}/").status_code, 200)

    def test_vehicle_quote(self):
        response = self.client.get(f"/api/v1/vehicles/{self.world['vehicle'].pk}/quote/", {"start": at(2).isoformat(), "end": at(4).isoformat()})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["total"], "66.60")

    def test_booking_requires_authentication(self):
        self.assertIn(self.client.get("/api/v1/bookings/").status_code, (401, 403))

    def test_create_pay_and_cancel_booking(self):
        self.client.login(username="api@test.example", password=PASSWORD)
        payload = {"vehicle": self.world["vehicle"].pk, "start_at": at(5).isoformat(), "end_at": at(7).isoformat(), "driver_name": "Api User", "driver_phone": "1"}
        created = self.client.post("/api/v1/bookings/", payload, content_type="application/json")
        self.assertEqual(created.status_code, 201, created.content)
        ref = created.json()["reference"]
        paid = self.client.post(f"/api/v1/bookings/{ref}/pay/", {"method": "card", "card_number": "4111111111111111", "holder": "Api"}, content_type="application/json")
        self.assertEqual(paid.json()["status"], "confirmed")
        clash = self.client.post("/api/v1/bookings/", {**payload, "start_at": at(6).isoformat()}, content_type="application/json")
        self.assertEqual(clash.status_code, 400)
        cancelled = self.client.post(f"/api/v1/bookings/{ref}/cancel/", {}, content_type="application/json")
        self.assertEqual(cancelled.json()["status"], "cancelled")

    def test_schema_is_generated(self):
        self.assertEqual(self.client.get("/api/schema/").status_code, 200)
