"""Payment gateway abstraction.

`SimulatedGateway` approves any plausible card number so the whole flow can be demoed.
It never stores card data. To go live, subclass `BaseGateway` for a provider that supports
your launch country (hosted checkout / tokenisation, so raw card numbers never touch this
server) and set PAYMENT_GATEWAY to its dotted path.
"""
import re
import secrets
from dataclasses import dataclass
from decimal import Decimal

from django.conf import settings
from django.utils.module_loading import import_string


@dataclass
class GatewayResult:
    ok: bool
    reference: str = ""
    message: str = ""


class BaseGateway:
    def charge(self, amount: Decimal, *, card_number: str, holder: str, reference: str) -> GatewayResult:
        raise NotImplementedError

    def refund(self, amount: Decimal, *, original_reference: str) -> GatewayResult:
        raise NotImplementedError


class SimulatedGateway(BaseGateway):
    """Test cards: any 13-19 digit number is approved, except numbers ending in 0002 (declined)."""

    def charge(self, amount, *, card_number, holder, reference):
        digits = re.sub(r"\D", "", card_number or "")
        if not 13 <= len(digits) <= 19:
            return GatewayResult(False, message="Enter a valid card number.")
        if digits.endswith("0002"):
            return GatewayResult(False, message="The card was declined. Try another card.")
        if amount <= 0:
            return GatewayResult(False, message="Nothing to charge.")
        return GatewayResult(True, reference="SIM-" + secrets.token_hex(6).upper())

    def refund(self, amount, *, original_reference):
        return GatewayResult(True, reference="SIMREF-" + secrets.token_hex(6).upper())


def get_gateway() -> BaseGateway:
    return import_string(settings.PAYMENT_GATEWAY)()
