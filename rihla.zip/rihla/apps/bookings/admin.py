from django.contrib import admin

from .models import Booking, Complaint, Payment, Review


class PaymentInline(admin.TabularInline):
    model = Payment
    extra = 0
    readonly_fields = ("kind", "method", "amount", "status", "gateway_reference", "created_at")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("reference", "vehicle", "customer", "partner", "status", "start_at", "end_at", "total", "commission_amount")
    list_filter = ("status", "mode", "partner")
    search_fields = ("reference", "customer__email", "driver_name", "vehicle__make", "vehicle__model")
    date_hierarchy = "start_at"
    inlines = [PaymentInline]
    readonly_fields = (
        "reference",
        "base_amount",
        "extras_amount",
        "delivery_fee",
        "discount_amount",
        "subtotal",
        "vat_amount",
        "total",
        "deposit",
        "commission_rate",
        "commission_amount",
        "partner_payout",
        "refund_amount",
        "created_at",
    )


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("booking", "kind", "method", "amount", "status", "created_at")
    list_filter = ("kind", "method", "status")
    search_fields = ("booking__reference", "gateway_reference")


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ("vehicle", "customer", "rating", "created_at")
    list_filter = ("rating",)


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ("subject", "booking", "user", "status", "created_at")
    list_filter = ("status",)
    search_fields = ("subject", "booking__reference", "user__email")
