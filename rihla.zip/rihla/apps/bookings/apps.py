import logging

from django.apps import AppConfig
from django.db import connections
from django.db.models.signals import post_migrate

logger = logging.getLogger(__name__)

CONSTRAINT = "booking_no_overlap"


def add_overlap_constraint(sender, using="default", **kwargs):
    """PostgreSQL only: make double-booking impossible at the database level.

    The application already locks the vehicle row and re-checks availability inside a
    transaction. This exclusion constraint is the safety net underneath: even a bug or a
    manual SQL edit cannot create two overlapping live bookings for one vehicle.
    """
    connection = connections[using]
    if connection.vendor != "postgresql":
        return
    from .models import Booking

    table = connection.ops.quote_name(Booking._meta.db_table)
    live = ", ".join(f"'{s}'" for s in Booking.BLOCKING_STATUSES)
    try:
        with connection.cursor() as cursor:
            cursor.execute("CREATE EXTENSION IF NOT EXISTS btree_gist")
            cursor.execute("SELECT 1 FROM pg_constraint WHERE conname = %s", [CONSTRAINT])
            if not cursor.fetchone():
                cursor.execute(
                    f"ALTER TABLE {table} ADD CONSTRAINT {CONSTRAINT} "
                    "EXCLUDE USING gist (vehicle_id WITH =, tstzrange(start_at, end_at) WITH &&) "
                    f"WHERE (status IN ({live}))"
                )
                logger.info("Created PostgreSQL constraint %s", CONSTRAINT)
    except Exception:
        logger.exception("Could not create the %s constraint (application-level checks still apply)", CONSTRAINT)


class BookingsConfig(AppConfig):
    name = "apps.bookings"
    verbose_name = "Bookings and payments"

    def ready(self):
        post_migrate.connect(add_overlap_constraint, sender=self)
