import secrets
from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Sum
from django.utils import timezone


def _money(**kwargs):
    return models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"), **kwargs)


class Booking(models.Model):
    PENDING_PAYMENT, REQUESTED, CONFIRMED, ACTIVE, COMPLETED, DECLINED, CANCELLED, EXPIRED = (
        "pending_payment",
        "requested",
        "confirmed",
        "active",
        "completed",
        "declined",
        "cancelled",
        "expired",
    )
    STATUS_CHOICES = [
        (PENDING_PAYMENT, "Awaiting payment"),
        (REQUESTED, "Request sent"),
        (CONFIRMED, "Confirmed"),
        (ACTIVE, "On the road"),
        (COMPLETED, "Completed"),
        (DECLINED, "Declined"),
        (CANCELLED, "Cancelled"),
        (EXPIRED, "Expired"),
    ]
    # Statuses that occupy the vehicle. Requests do NOT block until the partner accepts.
    BLOCKING_STATUSES = (PENDING_PAYMENT, CONFIRMED, ACTIVE)

    INSTANT, REQUEST = "instant", "request"
    MODE_CHOICES = [(INSTANT, "Instant booking"), (REQUEST, "Booking request")]

    reference = models.CharField(max_length=14, unique=True, editable=False)
    vehicle = models.ForeignKey("fleet.Vehicle", on_delete=models.PROTECT, related_name="bookings")
    partner = models.ForeignKey("accounts.Partner", on_delete=models.PROTECT, related_name="bookings")
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="bookings")
    mode = models.CharField(max_length=20, choices=MODE_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, db_index=True)

    start_at = models.DateTimeField(db_index=True)
    end_at = models.DateTimeField()
    days = models.PositiveSmallIntegerField()

    driver_name = models.CharField(max_length=120)
    driver_phone = models.CharField(max_length=30)
    notes = models.TextField(blank=True)
    delivery_requested = models.BooleanField(default=False)
    delivery_address = models.CharField(max_length=200, blank=True)
    extras = models.JSONField(default=list, blank=True)

    # Money, all in USD and frozen at booking time so later price edits never change history.
    base_amount = _money()
    extras_amount = _money()
    delivery_fee = _money()
    discount_amount = _money()
    subtotal = _money()
    vat_amount = _money()
    total = _money()
    deposit = _money()
    commission_rate = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    commission_amount = _money()
    partner_payout = _money()
    promo_code = models.ForeignKey("core.PromoCode", null=True, blank=True, on_delete=models.SET_NULL, related_name="bookings")
    cancellation_policy = models.CharField(max_length=20)

    hold_expires_at = models.DateTimeField(null=True, blank=True, db_index=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    cancel_reason = models.CharField(max_length=300, blank=True)
    decline_reason = models.CharField(max_length=300, blank=True)
    refund_amount = _money()
    reminder_sent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["vehicle", "start_at", "end_at"])]

    def __str__(self):
        return f"{self.reference} {self.vehicle}"

    def save(self, *args, **kwargs):
        if not self.reference:
            while True:
                ref = "RIH-" + secrets.token_hex(4).upper()
                if not Booking.objects.filter(reference=ref).exists():
                    self.reference = ref
                    break
        super().save(*args, **kwargs)

    # --- convenience --------------------------------------------------------------
    @property
    def is_blocking(self):
        return self.status in self.BLOCKING_STATUSES

    @property
    def can_cancel(self):
        return self.status in (self.PENDING_PAYMENT, self.REQUESTED, self.CONFIRMED)

    @property
    def can_pay(self):
        return self.status == self.PENDING_PAYMENT and (self.hold_expires_at is None or self.hold_expires_at > timezone.now())

    @property
    def can_review(self):
        return self.status == self.COMPLETED and not hasattr(self, "review")

    @property
    def extras_labels(self):
        return [settings.EXTRAS[k]["label"] for k in self.extras if k in settings.EXTRAS]

    @property
    def amount_paid(self):
        """Money actually received, net of refunds."""
        agg = self.payments.filter(status=Payment.SUCCEEDED).values("kind").annotate(s=Sum("amount"))
        totals = {row["kind"]: row["s"] for row in agg}
        return totals.get(Payment.CHARGE, Decimal("0.00")) - totals.get(Payment.REFUND, Decimal("0.00"))

    @property
    def badge(self):
        return {
            self.CONFIRMED: "ok",
            self.ACTIVE: "ok",
            self.COMPLETED: "muted",
            self.PENDING_PAYMENT: "warn",
            self.REQUESTED: "warn",
        }.get(self.status, "bad")


class Payment(models.Model):
    CHARGE, REFUND = "charge", "refund"
    KIND_CHOICES = [(CHARGE, "Charge"), (REFUND, "Refund")]
    CARD, CASH = "card", "cash"
    METHOD_CHOICES = [(CARD, "Card (online)"), (CASH, "Cash at pickup")]
    PENDING, SUCCEEDED, FAILED = "pending", "succeeded", "failed"
    STATUS_CHOICES = [(PENDING, "Pending"), (SUCCEEDED, "Succeeded"), (FAILED, "Failed")]

    booking = models.ForeignKey(Booking, on_delete=models.PROTECT, related_name="payments")
    kind = models.CharField(max_length=10, choices=KIND_CHOICES, default=CHARGE)
    method = models.CharField(max_length=10, choices=METHOD_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)
    gateway_reference = models.CharField(max_length=60, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"{self.get_kind_display()} ${self.amount} {self.get_status_display()}"


class Review(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="review")
    vehicle = models.ForeignKey("fleet.Vehicle", on_delete=models.CASCADE, related_name="reviews")
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveSmallIntegerField(choices=[(i, str(i)) for i in range(1, 6)])
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.rating}/5 for {self.vehicle}"


class Complaint(models.Model):
    OPEN, INVESTIGATING, RESOLVED, DISMISSED = "open", "investigating", "resolved", "dismissed"
    STATUS_CHOICES = [
        (OPEN, "Open"),
        (INVESTIGATING, "Investigating"),
        (RESOLVED, "Resolved"),
        (DISMISSED, "Dismissed"),
    ]

    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="complaints")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="complaints")
    subject = models.CharField(max_length=140)
    message = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=OPEN, db_index=True)
    resolution = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.subject} ({self.get_status_display()})"
