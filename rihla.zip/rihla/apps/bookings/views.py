from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_POST

from apps.core.audit import audit
from apps.core.utils import parse_dt
from apps.fleet.models import Vehicle

from .forms import CheckoutForm, ComplaintForm, PayForm, ReviewForm
from .models import Booking, Payment
from .services import (
    BookingError,
    cancel_booking,
    create_booking,
    expire_stale,
    pay_booking,
    quote,
    quote_to_json,
)


def _get_booking_for(request, ref):
    """Fetch a booking the current user may see: its customer, its partner, or staff."""
    booking = get_object_or_404(
        Booking.objects.select_related("vehicle", "vehicle__city", "partner", "customer"),
        reference=ref,
    )
    user = request.user
    is_customer = booking.customer_id == user.pk
    is_partner = booking.partner.owner_id == user.pk
    if not (is_customer or is_partner or user.is_staff):
        raise PermissionDenied
    return booking, is_customer, is_partner


@require_GET
def quote_json(request):
    """Live price for the booking box. Public: prices are not secret."""
    vehicle = get_object_or_404(
        Vehicle.objects.select_related("partner", "city", "city__country"), pk=request.GET.get("vehicle"), status=Vehicle.ACTIVE
    )
    start, end = parse_dt(request.GET.get("start")), parse_dt(request.GET.get("end"))
    if not start or not end:
        return JsonResponse({"error": "Choose pickup and return times."}, status=400)
    if end <= start:
        return JsonResponse({"error": "Return time must be after pickup time."}, status=400)
    from .services import is_available

    data = quote(vehicle, start, end, request.GET.getlist("extras"), request.GET.get("delivery") == "1", request.GET.get("promo", ""))
    payload = quote_to_json(data)
    payload["available"] = is_available(vehicle, start, end)
    return JsonResponse(payload)


@login_required
def checkout(request, vehicle_id):
    vehicle = get_object_or_404(
        Vehicle.objects.select_related("partner", "city", "city__country"), pk=vehicle_id, status=Vehicle.ACTIVE
    )
    source = request.POST if request.method == "POST" else request.GET
    start, end = parse_dt(source.get("start")), parse_dt(source.get("end"))
    if not start or not end or end <= start:
        messages.error(request, "Choose valid pickup and return times first.")
        return redirect("fleet:detail", pk=vehicle.pk)

    extras = source.getlist("extras")
    delivery = source.get("delivery") == "1"
    promo = source.get("promo", "")
    priced = quote(vehicle, start, end, extras, delivery, promo)

    form = CheckoutForm(request.POST or None, initial={"driver_name": request.user.get_full_name(), "driver_phone": request.user.phone})
    if request.method == "POST" and form.is_valid():
        try:
            booking = create_booking(
                customer=request.user,
                vehicle=vehicle,
                start=start,
                end=end,
                extras=extras,
                delivery=delivery,
                delivery_address=form.cleaned_data["delivery_address"],
                promo_code=promo,
                driver_name=form.cleaned_data["driver_name"],
                driver_phone=form.cleaned_data["driver_phone"],
                notes=form.cleaned_data["notes"],
            )
        except BookingError as exc:
            messages.error(request, str(exc))
        else:
            if booking.mode == Booking.INSTANT:
                return redirect("bookings:pay", ref=booking.reference)
            messages.success(request, "Request sent. The owner has 24 hours to answer.")
            return redirect("bookings:detail", ref=booking.reference)

    return render(
        request,
        "bookings/checkout.html",
        {
            "vehicle": vehicle,
            "quote": priced,
            "form": form,
            "start": source.get("start"),
            "end": source.get("end"),
            "start_dt": start,
            "end_dt": end,
            "extras_selected": extras,
            "extras_labels": [settings.EXTRAS[k]["label"] for k in priced["extras"]],
            "delivery": delivery,
            "promo": promo,
        },
    )


@login_required
def my_bookings(request):
    expire_stale()
    bookings = Booking.objects.filter(customer=request.user).select_related("vehicle", "vehicle__city", "partner").prefetch_related("vehicle__photos")
    return render(request, "bookings/my_bookings.html", {"bookings": bookings})


@login_required
def booking_detail(request, ref):
    expire_stale()
    booking, is_customer, is_partner = _get_booking_for(request, ref)
    return render(
        request,
        "bookings/detail.html",
        {
            "booking": booking,
            "is_customer": is_customer,
            "is_partner": is_partner,
            "payments": booking.payments.all(),
            "complaints": booking.complaints.all() if is_customer or request.user.is_staff else [],
        },
    )


@login_required
def pay(request, ref):
    booking, is_customer, _ = _get_booking_for(request, ref)
    if not is_customer:
        raise PermissionDenied
    if not booking.can_pay:
        messages.info(request, "This booking is not waiting for payment.")
        return redirect("bookings:detail", ref=ref)
    form = PayForm(request.POST or None, allow_cash=booking.vehicle.pay_at_pickup)
    if request.method == "POST" and form.is_valid():
        try:
            pay_booking(
                booking,
                method=form.cleaned_data["method"],
                card_number=form.cleaned_data["card_number"],  # passed to the gateway, never stored
                holder=form.cleaned_data["holder"],
            )
        except BookingError as exc:
            messages.error(request, str(exc))
        else:
            messages.success(request, "Booking confirmed. Have a great trip!")
            return redirect("bookings:detail", ref=ref)
    return render(request, "bookings/pay.html", {"booking": booking, "form": form})


@login_required
@require_POST
def cancel(request, ref):
    booking, is_customer, _ = _get_booking_for(request, ref)
    if not is_customer:
        raise PermissionDenied
    try:
        cancelled = cancel_booking(booking, request.user, request.POST.get("reason", ""))
    except BookingError as exc:
        messages.error(request, str(exc))
    else:
        if cancelled.refund_amount > 0:
            messages.success(request, f"Booking cancelled. ${cancelled.refund_amount} is being refunded.")
        else:
            messages.success(request, "Booking cancelled.")
    return redirect("bookings:detail", ref=ref)


@login_required
def receipt(request, ref):
    booking, _, _ = _get_booking_for(request, ref)
    if booking.status in (Booking.REQUESTED, Booking.PENDING_PAYMENT, Booking.EXPIRED, Booking.DECLINED):
        messages.info(request, "A receipt is available once the booking is confirmed.")
        return redirect("bookings:detail", ref=ref)
    return render(request, "bookings/receipt.html", {"booking": booking, "payments": booking.payments.exclude(status=Payment.FAILED)})


@login_required
def review(request, ref):
    booking, is_customer, _ = _get_booking_for(request, ref)
    if not is_customer or not booking.can_review:
        messages.info(request, "You can review a trip once it is completed.")
        return redirect("bookings:detail", ref=ref)
    form = ReviewForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        item = form.save(commit=False)
        item.booking, item.vehicle, item.customer = booking, booking.vehicle, request.user
        item.save()
        messages.success(request, "Thanks for your review.")
        return redirect("fleet:detail", pk=booking.vehicle_id)
    return render(request, "partials/form_page.html", {"form": form, "title": f"Review your {booking.vehicle.title}", "submit": "Post review", "back": None})


@login_required
def complaint(request, ref):
    booking, is_customer, _ = _get_booking_for(request, ref)
    if not is_customer:
        raise PermissionDenied
    form = ComplaintForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        item = form.save(commit=False)
        item.booking, item.user = booking, request.user
        item.save()
        audit(request.user, "complaint.created", item, item.subject, request)
        messages.success(request, "Complaint received. Our team will contact you.")
        return redirect("bookings:detail", ref=ref)
    return render(request, "partials/form_page.html", {"form": form, "title": f"Report a problem with {booking.reference}", "submit": "Send complaint", "back": None})
