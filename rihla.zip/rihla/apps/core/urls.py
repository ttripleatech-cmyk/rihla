from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("partners/", views.partners_landing, name="partners"),
    path("how-it-works/", views.how_it_works, name="how_it_works"),
    path("terms/", views.terms, name="terms"),
    path("healthz/", views.healthz, name="healthz"),
]
