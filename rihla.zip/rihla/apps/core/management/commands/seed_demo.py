"""Populate a fresh database with realistic Lebanese demo data.

    python manage.py seed_demo

Creates the launch market (Lebanon, USD, 11% VAT), cities, subscription plans, promo
codes, demo partners with vehicles, customers, finished trips with reviews, an upcoming
booking and an open request, so every screen has something to show.
"""
import os
import secrets
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from apps.accounts.models import Partner, PartnerDocument, SubscriptionPlan
from apps.bookings import services
from apps.bookings.models import Payment, Review
from apps.core.models import City, Country, PromoCode
from apps.fleet.models import BlockedPeriod, Vehicle

User = get_user_model()

CITIES = [
    ("Beirut", "beirut", "33.8938", "35.5018", True, "The capital and the coast"),
    ("Beirut Airport (BEY)", "beirut-airport", "33.8209", "35.4884", True, "Pick up on arrival"),
    ("Jounieh", "jounieh", "33.9808", "35.6178", True, "Gateway to Keserwan"),
    ("Byblos (Jbeil)", "byblos", "34.1230", "35.6519", True, "Old harbour and beaches"),
    ("Tripoli", "tripoli", "34.4367", "35.8497", True, "The north"),
    ("Sidon", "sidon", "33.5630", "35.3688", False, ""),
    ("Tyre", "tyre", "33.2705", "35.2038", False, ""),
    ("Zahle", "zahle", "33.8467", "35.9020", False, "Bekaa valley"),
]

# name, audience, price, commission %, max vehicles, featured, description
PLANS = [
    ("Owner Free", "individual", "0", "18", 2, False, "Start with one or two cars. No monthly fee."),
    ("Owner Plus", "individual", "9", "12", 5, False, "More cars and a lower commission."),
    ("Fleet Starter", "company", "49", "12", 15, False, "For small rental offices."),
    ("Fleet Pro", "company", "149", "9", 60, True, "Higher placement in search and a low commission."),
    ("Fleet Enterprise", "company", "399", "6", None, True, "Unlimited vehicles and the lowest rate."),
]

# owner key, city, make, model, year, category, transmission, fuel, seats, daily, weekly, monthly, deposit, mode, policy, features
VEHICLES = [
    ("cedar", "beirut", "Kia", "Picanto", 2023, "economy", "automatic", "petrol", 4, 28, 170, 600, 200, "instant", "flexible", "Bluetooth, USB, Parking sensors"),
    ("cedar", "beirut", "Hyundai", "Accent", 2022, "economy", "manual", "petrol", 5, 26, 160, 560, 200, "instant", "flexible", "Bluetooth, USB"),
    ("cedar", "beirut", "Toyota", "Corolla", 2023, "sedan", "automatic", "hybrid", 5, 42, 260, 900, 300, "instant", "moderate", "Apple CarPlay, Reversing camera, Cruise control"),
    ("cedar", "beirut", "Kia", "Sportage", 2023, "suv", "automatic", "petrol", 5, 65, 400, 1500, 400, "instant", "moderate", "Apple CarPlay, Panoramic roof, Reversing camera"),
    ("cedar", "beirut-airport", "Toyota", "RAV4", 2022, "suv", "automatic", "hybrid", 5, 75, 470, 1700, 500, "instant", "moderate", "Apple CarPlay, Heated seats, Cruise control"),
    ("cedar", "beirut", "Mercedes-Benz", "C 200", 2022, "luxury", "automatic", "petrol", 5, 130, 800, 2900, 800, "request", "strict", "Leather seats, Navigation, Ambient lighting"),
    ("cedar", "beirut-airport", "BMW", "X5", 2022, "luxury", "automatic", "diesel", 5, 165, 1000, 3600, 1000, "request", "strict", "Leather seats, Head-up display, 360 camera"),
    ("cedar", "jounieh", "Hyundai", "H1", 2021, "van", "automatic", "diesel", 9, 95, 600, 2200, 500, "instant", "moderate", "9 seats, Rear A/C, Large luggage space"),
    ("karim", "jounieh", "Suzuki", "Swift", 2020, "compact", "manual", "petrol", 5, 24, 150, 520, 150, "request", "flexible", "Bluetooth, USB"),
    ("karim", "jounieh", "Renault", "Clio", 2021, "compact", "automatic", "petrol", 5, 30, 185, None, 200, "instant", "flexible", "Bluetooth, Parking sensors"),
    ("karim", "byblos", "Jeep", "Wrangler", 2019, "suv", "manual", "petrol", 4, 85, 520, None, 500, "request", "moderate", "Removable top, 4x4, Bluetooth"),
    ("karim", "byblos", "Mini", "Cooper Convertible", 2020, "convertible", "automatic", "petrol", 4, 90, 560, None, 500, "request", "moderate", "Convertible roof, Navigation"),
    ("karim", "beirut", "Tesla", "Model 3", 2021, "sedan", "automatic", "electric", 5, 110, 680, 2400, 700, "request", "moderate", "Autopilot, Fast charging, Glass roof"),
    ("karim", "tripoli", "Mitsubishi", "Lancer", 2018, "sedan", "automatic", "petrol", 5, 22, 135, 470, 150, "request", "flexible", "Bluetooth, USB"),
]


class Command(BaseCommand):
    help = "Create demo data: Lebanon, plans, partners, vehicles, customers, trips and reviews."

    def add_arguments(self, parser):
        parser.add_argument("--password", default=None, help="Password for all demo accounts (random when DEBUG is off)")

    @transaction.atomic
    def handle(self, *args, **options):
        if Partner.objects.exists() or Country.objects.exists():
            raise CommandError("The database already has data. Run seed_demo on an empty database only.")
        # Known password only for local development. On a live site the demo accounts get a random
        # password (or DEMO_PASSWORD) that is printed once to the log: never leave demo users in production.
        password = options["password"] or (
            "Rihla#Demo2026" if settings.DEBUG else os.environ.get("DEMO_PASSWORD") or secrets.token_urlsafe(9) + "#1a"
        )
        now = timezone.now().replace(minute=0, second=0, microsecond=0)

        lebanon = Country.objects.create(code="LB", name="Lebanon", currency="USD", vat_rate=Decimal("11.00"))
        cities = {}
        for name, slug, lat, lng, featured, tagline in CITIES:
            cities[slug] = City.objects.create(country=lebanon, name=name, slug=slug, latitude=lat, longitude=lng, is_featured=featured, tagline=tagline)

        plans = {}
        for i, (name, audience, price, commission, max_v, featured, desc) in enumerate(PLANS):
            plans[name] = SubscriptionPlan.objects.create(
                name=name, audience=audience, monthly_price=Decimal(price), commission_percent=Decimal(commission),
                max_vehicles=max_v, featured_listings=featured, description=desc, sort_order=i,
            )

        PromoCode.objects.create(code="WELCOME10", description="10% off your first trip", percent_off=Decimal("10"), min_days=2)
        PromoCode.objects.create(code="RIHLA20", description="Launch offer", percent_off=Decimal("20"), max_uses=100, min_days=3, valid_until=now + timedelta(days=60))

        def make_user(email, first, last, staff=False, **extra):
            user = User.objects.create_user(username=email, email=email, password=password, first_name=first, last_name=last, email_verified=True, **extra)
            if staff:
                user.is_staff = user.is_superuser = True
                user.save()
            return user

        admin = make_user("admin@rihla.test", "Rihla", "Admin", staff=True)
        cedar_user = make_user("cedar@rihla.test", "Nadim", "Haddad", role="partner", phone="+961 1 555 100")
        karim_user = make_user("karim@rihla.test", "Karim", "Khoury", role="partner", phone="+961 3 555 200")
        byblos_user = make_user("byblos@rihla.test", "Rita", "Saade", role="partner", phone="+961 70 555 300")
        layla = make_user("layla@rihla.test", "Layla", "Mansour", phone="+961 71 555 400", driving_license_number="LB-1234567")
        omar = make_user("omar@rihla.test", "Omar", "Fakhoury", phone="+961 76 555 500", driving_license_number="LB-7654321")

        partners = {
            "cedar": Partner.objects.create(
                owner=cedar_user, partner_type="company", name="Cedar Fleet Rentals", city=cities["beirut"], address="Charles Helou Avenue, Beirut",
                phone="+961 1 555 100", registration_number="CR-1049382", status="approved", verified=True, plan=plans["Fleet Pro"],
                description="Family-run rental office near the port since 2009. New cars, English and Arabic spoken, airport delivery.",
            ),
            "karim": Partner.objects.create(
                owner=karim_user, partner_type="individual", name="Karim's Cars", city=cities["jounieh"], phone="+961 3 555 200",
                status="approved", verified=True, plan=plans["Owner Plus"],
                description="A few well-kept cars I rent out when I am not using them. Happy to meet you for handover.",
            ),
            "byblos": Partner.objects.create(
                owner=byblos_user, partner_type="company", name="Byblos Wheels", city=cities["byblos"], phone="+961 70 555 300",
                registration_number="CR-2201940", status="pending", description="New rental office near the old souk.",
            ),
        }
        PartnerDocument.objects.create(partner=partners["byblos"], kind="commercial_registration", file=ContentFile(b"%PDF-1.4 demo document", name="commercial-registration.pdf"))

        vehicles = []
        for (owner, city, make, model, year, cat, trans, fuel, seats, daily, weekly, monthly, deposit, mode, policy, features) in VEHICLES:
            partner = partners[owner]
            vehicles.append(
                Vehicle.objects.create(
                    partner=partner, city=cities[city], make=make, model=model, year=year, category=cat, transmission=trans, fuel=fuel,
                    seats=seats, doors=5 if seats > 4 else 4, bags=3 if cat in ("suv", "van", "luxury") else 2, color="",
                    features=features, description=f"{make} {model} in excellent condition, serviced regularly and cleaned before every rental.",
                    daily_price=Decimal(daily), weekly_price=Decimal(weekly) if weekly else None, monthly_price=Decimal(monthly) if monthly else None,
                    deposit=Decimal(deposit), mileage_limit_per_day=250 if cat != "luxury" else 200, extra_km_fee=Decimal("0.30"),
                    insurance_included=True, insurance_details="Third-party and collision cover. Excess equals the deposit.",
                    min_driver_age=25 if cat in ("luxury", "convertible") else 21, min_license_years=2 if cat == "luxury" else 1,
                    rental_conditions="Return with the same fuel level. No smoking. Travel outside Lebanon is not allowed.",
                    delivery_available=owner == "cedar", delivery_fee=Decimal("15") if owner == "cedar" else Decimal("0"),
                    pickup_address=partner.address or "", pay_at_pickup=True, booking_mode=mode, cancellation_policy=policy, status="active",
                )
            )

        # Finished trips with reviews (instant vehicles only, so they can be created without partner action).
        history = [(0, layla, 5, 5, "Spotless little car and an easy handover. Would rent again."), (2, layla, 5, 4, "Great on fuel around the city."),
                   (3, omar, 4, 5, "Perfect for the mountain roads. Cedar Fleet were very helpful."), (0, omar, 4, 4, "Smooth pickup at the office."),
                   (9, layla, 3, 5, "Karim was flexible with the pickup time."), (4, omar, 3, 5, "Collected at the airport in minutes.")]
        for idx, (vi, customer, days, rating, comment) in enumerate(history):
            vehicle = vehicles[vi]
            start = now - timedelta(days=60 - idx * 7)
            booking = services.create_booking(
                customer=customer, vehicle=vehicle, start=start, end=start + timedelta(days=days), driver_name=customer.get_full_name(),
                driver_phone=customer.phone, allow_past=True,
            )
            services.pay_booking(booking, method=Payment.CARD, card_number="4111111111111111", holder=customer.get_full_name())
            services.start_rental(booking, admin)
            services.complete_rental(booking, admin)
            Review.objects.create(booking=booking, vehicle=vehicle, customer=customer, rating=rating, comment=comment)

        # An upcoming confirmed booking, an open request for the partner to answer, and a blocked period.
        upcoming = services.create_booking(
            customer=layla, vehicle=vehicles[3], start=now + timedelta(days=10), end=now + timedelta(days=14), extras=["gps"],
            driver_name=layla.get_full_name(), driver_phone=layla.phone, promo_code="WELCOME10",
        )
        services.pay_booking(upcoming, method=Payment.CARD, card_number="4111111111111111", holder=layla.get_full_name())
        services.create_booking(
            customer=omar, vehicle=vehicles[5], start=now + timedelta(days=5), end=now + timedelta(days=8),
            driver_name=omar.get_full_name(), driver_phone=omar.phone, notes="Business trip. Can you deliver to the Hamra hotel?",
        )
        BlockedPeriod.objects.create(vehicle=vehicles[1], start_at=now + timedelta(days=3), end_at=now + timedelta(days=6), reason="Annual service")

        self.stdout.write(self.style.SUCCESS("Demo data created."))
        self.stdout.write(f"  Admin     admin@rihla.test / {password}")
        self.stdout.write(f"  Company   cedar@rihla.test / {password}   (Cedar Fleet Rentals, has an open request)")
        self.stdout.write(f"  Owner     karim@rihla.test / {password}")
        self.stdout.write(f"  Pending   byblos@rihla.test / {password}  (waiting for admin approval)")
        self.stdout.write(f"  Customer  layla@rihla.test / {password}")
        self.stdout.write("  Promo codes: WELCOME10, RIHLA20")
