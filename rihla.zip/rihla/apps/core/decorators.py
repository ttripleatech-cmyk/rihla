from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect


def staff_required(view):
    @wraps(view)
    @login_required
    def wrapper(request, *args, **kwargs):
        if not request.user.is_staff:
            raise PermissionDenied
        return view(request, *args, **kwargs)

    return wrapper


def partner_required(view):
    """Requires a logged-in user who has applied as a partner (any status)."""

    @wraps(view)
    @login_required
    def wrapper(request, *args, **kwargs):
        partner = request.user.partner_profile
        if partner is None:
            messages.info(request, "Apply as a rental partner to open the partner portal.")
            return redirect("accounts:partner_apply")
        request.partner = partner
        return view(request, *args, **kwargs)

    return wrapper
