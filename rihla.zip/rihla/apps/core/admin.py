from django.contrib import admin

from .models import City, Country, PromoCode


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "currency", "vat_rate", "is_active")


@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ("name", "country", "is_featured")
    list_filter = ("country", "is_featured")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(PromoCode)
class PromoCodeAdmin(admin.ModelAdmin):
    list_display = ("code", "percent_off", "times_used", "max_uses", "valid_until", "is_active")
    list_filter = ("is_active",)
