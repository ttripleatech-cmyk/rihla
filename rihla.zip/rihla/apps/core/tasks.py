import logging
from datetime import timedelta

from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task
def send_email_task(to, subject, body):
    try:
        send_mail(subject, body, settings.DEFAULT_FROM_EMAIL, [to], fail_silently=False)
    except Exception:
        logger.exception("E-mail to %s failed", to)


@shared_task
def expire_holds_task():
    from apps.bookings.services import expire_stale

    return expire_stale()


@shared_task
def pickup_reminders_task():
    """Remind customers about pickups starting in roughly the next day."""
    from apps.bookings.models import Booking

    from .notify import notify

    now = timezone.now()
    due = Booking.objects.filter(
        status=Booking.CONFIRMED,
        reminder_sent=False,
        start_at__gte=now,
        start_at__lte=now + timedelta(hours=26),
    ).select_related("customer", "vehicle")
    count = 0
    for booking in due:
        notify(
            booking.customer,
            f"Reminder: pickup tomorrow ({booking.reference})",
            f"Hi {booking.customer.first_name or 'there'},\n\n"
            f"Your {booking.vehicle.title} is ready for pickup on "
            f"{timezone.localtime(booking.start_at):%A %d %B at %H:%M}.\n"
            "Please bring your driving licence and ID.\n\nSafe travels,\nRihla Car Rental",
        )
        booking.reminder_sent = True
        booking.save(update_fields=["reminder_sent"])
        count += 1
    return count
