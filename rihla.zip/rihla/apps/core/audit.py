from .utils import client_ip


def audit(user, action, obj=None, detail="", request=None):
    """Record a sensitive action. Never raises: auditing must not break the request."""
    from apps.accounts.models import AuditLog

    try:
        AuditLog.objects.create(
            user=user if getattr(user, "is_authenticated", False) else None,
            action=action,
            object_type=obj.__class__.__name__ if obj is not None else "",
            object_id=str(obj.pk) if obj is not None else "",
            detail=(detail or "")[:2000],
            ip=client_ip(request),
        )
    except Exception:  # pragma: no cover - defensive
        import logging

        logging.getLogger(__name__).exception("Could not write audit log entry")
