import logging

from django.conf import settings

logger = logging.getLogger(__name__)


def notify(recipient, subject, body):
    """Queue an e-mail to a user (or a plain address). Never raises."""
    from .tasks import send_email_task

    address = getattr(recipient, "email", recipient)
    if not address:
        return
    try:
        send_email_task.delay(address, f"[{settings.PLATFORM_NAME}] {subject}", body)
    except Exception:
        logger.exception("Could not queue notification to %s", address)
