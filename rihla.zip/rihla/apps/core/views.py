from django.core.cache import cache
from django.db import connection
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone

from apps.accounts.models import SubscriptionPlan
from apps.fleet.models import Vehicle
from apps.fleet.search import search_vehicles

from .models import City


def home(request):
    featured = list(search_vehicles({"sort": "recommended"})[:6])
    stats = cache.get_or_set(
        "home_stats",
        lambda: {
            "cars": Vehicle.objects.filter(status=Vehicle.ACTIVE).count(),
            "cities": City.objects.filter(vehicles__status=Vehicle.ACTIVE).distinct().count(),
        },
        120,
    )
    context = {
        "featured": featured,
        "cities": City.objects.filter(is_featured=True),
        "categories": Vehicle.CATEGORY_CHOICES,
        "stats": stats,
        "all_cities": City.objects.filter(country__is_active=True),
        "now": timezone.localtime().strftime("%Y-%m-%dT%H:%M"),
    }
    return render(request, "core/home.html", context)


def partners_landing(request):
    plans = SubscriptionPlan.objects.filter(is_active=True)
    return render(
        request,
        "core/partners.html",
        {
            "company_plans": [p for p in plans if p.audience in ("company", "any")],
            "owner_plans": [p for p in plans if p.audience in ("individual", "any")],
        },
    )


def how_it_works(request):
    return render(request, "core/how_it_works.html")


def terms(request):
    return render(request, "core/terms.html")


def healthz(request):
    """Liveness/readiness probe for load balancers and Docker."""
    with connection.cursor() as cursor:
        cursor.execute("SELECT 1")
    return JsonResponse({"status": "ok"})
