from datetime import datetime, time

from django.utils import timezone
from django.utils.dateparse import parse_date, parse_datetime


def parse_dt(value):
    """Parse '2026-11-01T10:00' (datetime-local) or '2026-11-01' into an aware datetime.

    Returns None for empty or invalid input. A bare date means 10:00 local time.
    """
    if not value:
        return None
    value = value.strip()
    try:
        dt = parse_datetime(value)
    except ValueError:
        dt = None
    if dt is None:
        try:
            day = parse_date(value)
        except ValueError:
            day = None
        if day is None:
            return None
        dt = datetime.combine(day, time(10, 0))
    if timezone.is_naive(dt):
        dt = timezone.make_aware(dt)
    return dt


def client_ip(request):
    if request is None:
        return None
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR")
