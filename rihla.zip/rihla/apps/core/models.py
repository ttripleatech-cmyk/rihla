from decimal import Decimal

from django.db import models
from django.utils import timezone


class Country(models.Model):
    """A market. Launch market is Lebanon; add rows to expand."""

    code = models.CharField(max_length=2, unique=True, help_text="ISO 3166-1 alpha-2, e.g. LB")
    name = models.CharField(max_length=80)
    currency = models.CharField(max_length=3, default="USD")
    vat_rate = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("0.00"), help_text="VAT percent added to rentals"
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "countries"

    def __str__(self):
        return self.name


class City(models.Model):
    country = models.ForeignKey(Country, on_delete=models.PROTECT, related_name="cities")
    name = models.CharField(max_length=80)
    slug = models.SlugField(unique=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    is_featured = models.BooleanField(default=False)
    tagline = models.CharField(max_length=120, blank=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "cities"

    def __str__(self):
        return self.name


class PromoCode(models.Model):
    code = models.CharField(max_length=32, unique=True)
    description = models.CharField(max_length=140, blank=True)
    percent_off = models.DecimalField(max_digits=5, decimal_places=2)
    max_uses = models.PositiveIntegerField(null=True, blank=True, help_text="Leave empty for unlimited")
    times_used = models.PositiveIntegerField(default=0, editable=False)
    min_days = models.PositiveSmallIntegerField(default=1)
    valid_from = models.DateTimeField(null=True, blank=True)
    valid_until = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.code} (-{self.percent_off}%)"

    def save(self, *args, **kwargs):
        self.code = self.code.strip().upper()
        super().save(*args, **kwargs)

    def check(self, days, now=None):
        """Return an error message, or an empty string when the code can be used."""
        now = now or timezone.now()
        if not self.is_active:
            return "This promo code is not active."
        if self.valid_from and now < self.valid_from:
            return "This promo code is not valid yet."
        if self.valid_until and now > self.valid_until:
            return "This promo code has expired."
        if self.max_uses is not None and self.times_used >= self.max_uses:
            return "This promo code has been fully used."
        if days < self.min_days:
            return f"This promo code needs a rental of at least {self.min_days} days."
        return ""
