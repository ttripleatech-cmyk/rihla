from django.conf import settings
from django.core.files.storage import FileSystemStorage


def private_storage():
    """Storage for sensitive uploads (driving licences, partner documents).

    Files live outside MEDIA_ROOT and are never mapped to a public URL; they are
    only reachable through the permission-checked `accounts:secure_file` view.
    In production point this at a private S3 bucket (django-storages) instead.
    """
    return FileSystemStorage(location=settings.PRIVATE_MEDIA_ROOT)
