from django.conf import settings
from django.core.cache import cache


def platform(request):
    """Variables available in every template."""
    from .models import City

    cities = cache.get_or_set(
        "nav_cities",
        lambda: list(City.objects.filter(is_featured=True).values("name", "slug")),
        300,
    )
    return {
        "PLATFORM_NAME": settings.PLATFORM_NAME,
        "PLATFORM_TAGLINE": settings.PLATFORM_TAGLINE,
        "nav_cities": cities,
    }
