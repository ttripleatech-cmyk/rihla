import csv

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.db.models import Count, Sum
from django.db.models.functions import TruncMonth
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.accounts.models import AuditLog, Partner, PartnerDocument, SubscriptionPayment, SubscriptionPlan
from apps.bookings import services
from apps.bookings.models import Booking, Complaint
from apps.core.audit import audit
from apps.core.decorators import staff_required
from apps.core.notify import notify
from apps.fleet.models import Vehicle

User = get_user_model()
REVENUE_STATUSES = [Booking.CONFIRMED, Booking.ACTIVE, Booking.COMPLETED]
ALLOWED_NEXT = ("manage:home", "manage:partners", "manage:vehicles", "manage:bookings", "manage:complaints")


def _next(request, default):
    """Only redirect to known dashboard pages, never to a user-supplied URL."""
    target = request.POST.get("next")
    return target if target in ALLOWED_NEXT else default


@staff_required
def home(request):
    services.expire_stale()
    money = Booking.objects.filter(status__in=REVENUE_STATUSES)
    totals = money.aggregate(gmv=Sum("total"), commission=Sum("commission_amount"), payout=Sum("partner_payout"), n=Count("id"))
    subs = SubscriptionPayment.objects.aggregate(total=Sum("amount"))["total"] or 0

    monthly = list(
        money.annotate(m=TruncMonth("created_at"))
        .values("m")
        .annotate(gmv=Sum("total"), commission=Sum("commission_amount"), n=Count("id"))
        .order_by("-m")[:6]
    )[::-1]
    peak = max([float(row["gmv"] or 0) for row in monthly] + [1])
    for row in monthly:
        row["pct"] = round(float(row["gmv"] or 0) / peak * 100)

    by_status = {row["status"]: row["n"] for row in Booking.objects.values("status").annotate(n=Count("id"))}
    context = {
        "totals": totals,
        "subscription_revenue": subs,
        "monthly": monthly,
        "by_status": [(label, by_status.get(code, 0)) for code, label in Booking.STATUS_CHOICES],
        "pending_partners": Partner.objects.filter(status=Partner.PENDING).count(),
        "pending_vehicles": Vehicle.objects.filter(status=Vehicle.PENDING).count(),
        "pending_documents": PartnerDocument.objects.filter(status=PartnerDocument.PENDING).count(),
        "open_complaints": Complaint.objects.filter(status__in=[Complaint.OPEN, Complaint.INVESTIGATING]).count(),
        "users": User.objects.count(),
        "partners": Partner.objects.filter(status=Partner.APPROVED).count(),
        "live_vehicles": Vehicle.objects.filter(status=Vehicle.ACTIVE).count(),
        "recent": Booking.objects.select_related("vehicle", "customer", "partner")[:10],
    }
    return render(request, "dashboard/admin_home.html", context)


@staff_required
def partners(request):
    items = Partner.objects.select_related("owner", "city", "plan").prefetch_related("documents")
    status = request.GET.get("status", "pending")
    if status != "all":
        items = items.filter(status=status)
    return render(request, "dashboard/admin_partners.html", {"partners": items, "status": status, "statuses": Partner.STATUS_CHOICES})


@staff_required
@require_POST
def partner_action(request, pk, action):
    partner = get_object_or_404(Partner, pk=pk)
    note = request.POST.get("note", "")[:300]
    if action == "approve":
        partner.status = Partner.APPROVED
        if not partner.plan_id:
            partner.plan = SubscriptionPlan.objects.filter(is_active=True, monthly_price=0, audience__in=["any", partner.partner_type]).first()
        text = "Your partner application was approved. You can now list vehicles."
    elif action == "reject":
        partner.status = Partner.REJECTED
        text = f"Your partner application was not approved. {note}"
    elif action == "suspend":
        partner.status = Partner.SUSPENDED
        text = f"Your partner account was suspended. {note}"
    elif action == "verify":
        partner.verified = True
        text = "Your account now carries the verified badge."
    elif action == "unverify":
        partner.verified = False
        text = ""
    else:
        raise Http404
    partner.review_note = note
    partner.save()
    audit(request.user, f"partner.{action}", partner, note, request)
    if text:
        notify(partner.owner, "Partner account update", text)
    messages.success(request, f"{partner.name}: {action} done.")
    return redirect(_next(request, "manage:partners"))


@staff_required
@require_POST
def document_action(request, pk, action):
    doc = get_object_or_404(PartnerDocument, pk=pk)
    if action not in ("approve", "reject"):
        raise Http404
    doc.status = PartnerDocument.APPROVED if action == "approve" else PartnerDocument.REJECTED
    doc.note = request.POST.get("note", "")[:200]
    doc.save(update_fields=["status", "note"])
    audit(request.user, f"document.{action}", doc, request=request)
    messages.success(request, f"Document {doc.status}.")
    return redirect(_next(request, "manage:partners"))


@staff_required
def vehicles(request):
    status = request.GET.get("status", Vehicle.PENDING)
    items = Vehicle.objects.select_related("partner", "city").prefetch_related("photos")
    if status != "all":
        items = items.filter(status=status)
    return render(request, "dashboard/admin_vehicles.html", {"vehicles": items[:100], "status": status, "statuses": Vehicle.STATUS_CHOICES})


@staff_required
@require_POST
def vehicle_action(request, pk, action):
    vehicle = get_object_or_404(Vehicle, pk=pk)
    if action == "approve":
        vehicle.status = Vehicle.ACTIVE
    elif action == "reject":
        vehicle.status = Vehicle.REJECTED
    elif action == "pause":
        vehicle.status = Vehicle.PAUSED
    else:
        raise Http404
    vehicle.save(update_fields=["status"])
    audit(request.user, f"vehicle.{action}", vehicle, request=request)
    notify(vehicle.partner.owner, f"Vehicle {vehicle.get_status_display().lower()}", f"Your {vehicle.title} is now: {vehicle.get_status_display()}.")
    messages.success(request, f"{vehicle.title}: {vehicle.get_status_display()}.")
    return redirect(_next(request, "manage:vehicles"))


@staff_required
def bookings(request):
    services.expire_stale()
    items = Booking.objects.select_related("vehicle", "customer", "partner")
    status = request.GET.get("status")
    if status:
        items = items.filter(status=status)
    term = request.GET.get("q")
    if term:
        items = items.filter(reference__icontains=term) | items.filter(customer__email__icontains=term)
    return render(request, "dashboard/admin_bookings.html", {"bookings": items[:200], "status": status, "statuses": Booking.STATUS_CHOICES, "q": term or ""})


@staff_required
def complaints(request):
    status = request.GET.get("status", Complaint.OPEN)
    items = Complaint.objects.select_related("booking", "user")
    if status != "all":
        items = items.filter(status=status)
    return render(request, "dashboard/admin_complaints.html", {"complaints": items, "status": status, "statuses": Complaint.STATUS_CHOICES})


@staff_required
@require_POST
def complaint_update(request, pk):
    item = get_object_or_404(Complaint, pk=pk)
    new_status = request.POST.get("status")
    if new_status not in dict(Complaint.STATUS_CHOICES):
        raise Http404
    item.status = new_status
    item.resolution = request.POST.get("resolution", "")[:2000]
    item.save()
    audit(request.user, "complaint.updated", item, new_status, request)
    notify(item.user, f"Update on your complaint: {item.subject}", f"Status: {item.get_status_display()}.\n{item.resolution}")
    messages.success(request, "Complaint updated.")
    return redirect("manage:complaints")


@staff_required
def audit_log(request):
    items = AuditLog.objects.select_related("user")
    term = request.GET.get("q")
    if term:
        items = items.filter(action__icontains=term)
    return render(request, "dashboard/admin_audit.html", {"entries": items[:300], "q": term or ""})


@staff_required
def report_csv(request):
    """Bookings export for accounting: one row per booking with the money split."""
    items = Booking.objects.select_related("vehicle", "partner", "customer").order_by("-created_at")
    status = request.GET.get("status")
    if status:
        items = items.filter(status=status)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="rihla-bookings-{timezone.localdate():%Y%m%d}.csv"'
    writer = csv.writer(response)
    writer.writerow(["reference", "created", "status", "partner", "vehicle", "customer", "start", "end", "days", "subtotal_usd", "vat_usd", "total_usd", "commission_pct", "commission_usd", "partner_payout_usd", "refund_usd"])
    for b in items.iterator():
        writer.writerow([b.reference, f"{b.created_at:%Y-%m-%d %H:%M}", b.status, b.partner.name, b.vehicle.title, b.customer.email, f"{b.start_at:%Y-%m-%d %H:%M}", f"{b.end_at:%Y-%m-%d %H:%M}", b.days, b.subtotal, b.vat_amount, b.total, b.commission_rate, b.commission_amount, b.partner_payout, b.refund_amount])
    return response
