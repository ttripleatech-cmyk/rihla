from django import forms

from apps.accounts.forms import validate_upload
from apps.fleet.models import BlockedPeriod, Vehicle, VehiclePhoto


class VehicleForm(forms.ModelForm):
    class Meta:
        model = Vehicle
        exclude = ["partner", "status", "created_at"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            "rental_conditions": forms.Textarea(attrs={"rows": 4}),
        }

    def clean(self):
        data = super().clean()
        daily, weekly, monthly = data.get("daily_price"), data.get("weekly_price"), data.get("monthly_price")
        if daily is not None and daily <= 0:
            self.add_error("daily_price", "The daily price must be above zero.")
        if daily and weekly and weekly > daily * 7:
            self.add_error("weekly_price", "The weekly price should not be higher than 7 daily rates.")
        if weekly and monthly and monthly > weekly * 5:
            self.add_error("monthly_price", "The monthly price should not be higher than 5 weekly rates.")
        return data


class PhotoForm(forms.ModelForm):
    class Meta:
        model = VehiclePhoto
        fields = ["image", "is_cover"]

    def clean_image(self):
        image = self.cleaned_data["image"]
        if image.size > 8 * 1024 * 1024:
            raise forms.ValidationError("Photos must be smaller than 8 MB.")
        return image


class BlockForm(forms.ModelForm):
    class Meta:
        model = BlockedPeriod
        fields = ["start_at", "end_at", "reason"]
        widgets = {
            "start_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
            "end_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name in ("start_at", "end_at"):
            self.fields[name].input_formats = ["%Y-%m-%dT%H:%M"]

    def clean(self):
        data = super().clean()
        if data.get("start_at") and data.get("end_at") and data["end_at"] <= data["start_at"]:
            self.add_error("end_at", "The end must be after the start.")
        return data
