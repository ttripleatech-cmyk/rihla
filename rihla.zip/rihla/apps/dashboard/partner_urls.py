from django.urls import path

from . import partner_views as v

app_name = "partner"

urlpatterns = [
    path("", v.home, name="home"),
    path("vehicles/", v.vehicles, name="vehicles"),
    path("vehicles/new/", v.vehicle_new, name="vehicle_new"),
    path("vehicles/<int:pk>/", v.vehicle_edit, name="vehicle_edit"),
    path("vehicles/<int:pk>/photo/", v.photo_add, name="photo_add"),
    path("vehicles/<int:pk>/block/", v.block_add, name="block_add"),
    path("vehicles/<int:pk>/toggle/", v.vehicle_toggle, name="vehicle_toggle"),
    path("photos/<int:pk>/delete/", v.photo_delete, name="photo_delete"),
    path("blocks/<int:pk>/delete/", v.block_delete, name="block_delete"),
    path("bookings/", v.bookings, name="bookings"),
    path("bookings/<str:ref>/<str:action>/", v.booking_action, name="booking_action"),
    path("documents/", v.documents, name="documents"),
    path("plans/", v.plans, name="plans"),
]
