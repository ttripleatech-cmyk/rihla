from django.urls import path

from . import admin_views as v

app_name = "manage"

urlpatterns = [
    path("", v.home, name="home"),
    path("partners/", v.partners, name="partners"),
    path("partners/<int:pk>/<str:action>/", v.partner_action, name="partner_action"),
    path("documents/<int:pk>/<str:action>/", v.document_action, name="document_action"),
    path("vehicles/", v.vehicles, name="vehicles"),
    path("vehicles/<int:pk>/<str:action>/", v.vehicle_action, name="vehicle_action"),
    path("bookings/", v.bookings, name="bookings"),
    path("complaints/", v.complaints, name="complaints"),
    path("complaints/<int:pk>/", v.complaint_update, name="complaint_update"),
    path("audit/", v.audit_log, name="audit"),
    path("reports/bookings.csv", v.report_csv, name="report_csv"),
]
