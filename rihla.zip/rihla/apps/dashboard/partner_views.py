from datetime import timedelta

from django.contrib import messages
from django.db.models import Count, Sum
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.accounts.forms import DocumentForm
from apps.accounts.models import SubscriptionPayment, SubscriptionPlan
from apps.bookings import services
from apps.bookings.models import Booking
from apps.bookings.services import BookingError
from apps.core.audit import audit
from apps.core.decorators import partner_required
from apps.fleet.models import BlockedPeriod, Vehicle, VehiclePhoto

from .forms import BlockForm, PhotoForm, VehicleForm

REVENUE_STATUSES = [Booking.CONFIRMED, Booking.ACTIVE, Booking.COMPLETED]


def _vehicle(request, pk):
    return get_object_or_404(Vehicle, pk=pk, partner=request.partner)


@partner_required
def home(request):
    services.expire_stale()
    partner = request.partner
    now = timezone.now()
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    mine = Booking.objects.filter(partner=partner)
    money = mine.filter(status__in=REVENUE_STATUSES)
    this_month = money.filter(created_at__gte=month_start).aggregate(gross=Sum("subtotal"), payout=Sum("partner_payout"), commission=Sum("commission_amount"))
    lifetime = money.aggregate(payout=Sum("partner_payout"), n=Count("id"))
    context = {
        "partner": partner,
        "requests": mine.filter(status=Booking.REQUESTED).select_related("vehicle", "customer").order_by("hold_expires_at"),
        "upcoming": mine.filter(status=Booking.CONFIRMED, start_at__gte=now - timedelta(days=1)).select_related("vehicle", "customer").order_by("start_at")[:8],
        "on_road": mine.filter(status=Booking.ACTIVE).select_related("vehicle", "customer"),
        "month": this_month,
        "lifetime": lifetime,
        "vehicle_count": partner.vehicles.count(),
        "live_count": partner.vehicles.filter(status=Vehicle.ACTIVE).count(),
        "commission_rate": partner.effective_commission(),
    }
    return render(request, "dashboard/partner_home.html", context)


@partner_required
def vehicles(request):
    items = request.partner.vehicles.select_related("city").prefetch_related("photos")
    return render(request, "dashboard/partner_vehicles.html", {"vehicles": items, "partner": request.partner})


@partner_required
def vehicle_new(request):
    partner = request.partner
    if not partner.can_add_vehicle():
        messages.error(request, f"Your plan allows {partner.vehicle_limit()} vehicles. Upgrade your plan to add more.")
        return redirect("partner:plans")
    form = VehicleForm(request.POST or None, initial={"city": partner.city})
    if request.method == "POST" and form.is_valid():
        vehicle = form.save(commit=False)
        vehicle.partner = partner
        # Verified companies go live straight away; everyone else waits for a quick review.
        auto_live = partner.is_approved and partner.is_company and partner.verified
        vehicle.status = Vehicle.ACTIVE if auto_live else Vehicle.PENDING
        vehicle.save()
        audit(request.user, "vehicle.created", vehicle, request=request)
        messages.success(request, "Vehicle saved. Add photos next." + ("" if auto_live else " It will go live after a quick review."))
        return redirect("partner:vehicle_edit", pk=vehicle.pk)
    return render(request, "dashboard/vehicle_form.html", {"form": form, "vehicle": None})


@partner_required
def vehicle_edit(request, pk):
    vehicle = _vehicle(request, pk)
    form = VehicleForm(request.POST or None, instance=vehicle)
    if request.method == "POST" and form.is_valid():
        form.save()
        audit(request.user, "vehicle.updated", vehicle, request=request)
        messages.success(request, "Vehicle updated.")
        return redirect("partner:vehicle_edit", pk=vehicle.pk)
    return render(
        request,
        "dashboard/vehicle_form.html",
        {
            "form": form,
            "vehicle": vehicle,
            "photos": vehicle.photos.all(),
            "photo_form": PhotoForm(),
            "blocks": vehicle.blocked_periods.filter(end_at__gte=timezone.now()),
            "block_form": BlockForm(),
        },
    )


@partner_required
@require_POST
def photo_add(request, pk):
    vehicle = _vehicle(request, pk)
    form = PhotoForm(request.POST, request.FILES)
    if form.is_valid():
        photo = form.save(commit=False)
        photo.vehicle = vehicle
        photo.position = vehicle.photos.count()
        if photo.is_cover:
            vehicle.photos.update(is_cover=False)
        photo.save()
        messages.success(request, "Photo added.")
    else:
        messages.error(request, "; ".join(e for errs in form.errors.values() for e in errs))
    return redirect("partner:vehicle_edit", pk=vehicle.pk)


@partner_required
@require_POST
def photo_delete(request, pk):
    photo = get_object_or_404(VehiclePhoto, pk=pk, vehicle__partner=request.partner)
    vehicle_id = photo.vehicle_id
    photo.image.delete(save=False)
    photo.delete()
    messages.success(request, "Photo removed.")
    return redirect("partner:vehicle_edit", pk=vehicle_id)


@partner_required
@require_POST
def block_add(request, pk):
    vehicle = _vehicle(request, pk)
    form = BlockForm(request.POST)
    if form.is_valid():
        block = form.save(commit=False)
        block.vehicle = vehicle
        block.save()
        messages.success(request, "Dates blocked.")
    else:
        messages.error(request, "; ".join(e for errs in form.errors.values() for e in errs))
    return redirect("partner:vehicle_edit", pk=vehicle.pk)


@partner_required
@require_POST
def block_delete(request, pk):
    block = get_object_or_404(BlockedPeriod, pk=pk, vehicle__partner=request.partner)
    vehicle_id = block.vehicle_id
    block.delete()
    messages.success(request, "Block removed.")
    return redirect("partner:vehicle_edit", pk=vehicle_id)


@partner_required
@require_POST
def vehicle_toggle(request, pk):
    vehicle = _vehicle(request, pk)
    if vehicle.status == Vehicle.ACTIVE:
        vehicle.status = Vehicle.PAUSED
        messages.success(request, "Vehicle paused. Customers can no longer book it.")
    elif vehicle.status == Vehicle.PAUSED:
        vehicle.status = Vehicle.ACTIVE
        messages.success(request, "Vehicle is live again.")
    else:
        messages.info(request, "This vehicle is waiting for review.")
        return redirect("partner:vehicles")
    vehicle.save(update_fields=["status"])
    audit(request.user, f"vehicle.{vehicle.status}", vehicle, request=request)
    return redirect("partner:vehicles")


@partner_required
def bookings(request):
    services.expire_stale()
    items = Booking.objects.filter(partner=request.partner).select_related("vehicle", "customer")
    status = request.GET.get("status")
    if status:
        items = items.filter(status=status)
    return render(request, "dashboard/partner_bookings.html", {"bookings": items[:100], "status": status, "statuses": Booking.STATUS_CHOICES})


@partner_required
@require_POST
def booking_action(request, ref, action):
    booking = get_object_or_404(Booking, reference=ref, partner=request.partner)
    try:
        if action == "accept":
            services.accept_request(booking, request.user)
            messages.success(request, "Request accepted. The customer has been asked to pay.")
        elif action == "decline":
            services.decline_request(booking, request.user, request.POST.get("reason", ""))
            messages.success(request, "Request declined.")
        elif action == "pickup":
            services.start_rental(booking, request.user)
            messages.success(request, "Marked as picked up.")
        elif action == "complete":
            services.complete_rental(booking, request.user)
            messages.success(request, "Rental completed. The customer was invited to review.")
        elif action == "cancel":
            services.cancel_booking(booking, request.user, request.POST.get("reason", "Cancelled by the owner"))
            messages.success(request, "Booking cancelled and the customer refunded in full.")
        else:
            raise Http404
    except BookingError as exc:
        messages.error(request, str(exc))
    target = request.POST.get("next")
    return redirect(target if target in ("partner:home", "partner:bookings") else "partner:bookings")


@partner_required
def documents(request):
    form = DocumentForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        doc = form.save(commit=False)
        doc.partner = request.partner
        doc.save()
        audit(request.user, "partner.document_uploaded", doc, request=request)
        messages.success(request, "Document uploaded. We will review it shortly.")
        return redirect("partner:documents")
    return render(request, "dashboard/partner_documents.html", {"form": form, "documents": request.partner.documents.all(), "partner": request.partner})


@partner_required
def plans(request):
    partner = request.partner
    available = SubscriptionPlan.objects.filter(is_active=True, audience__in=["any", partner.partner_type])
    if request.method == "POST":
        plan = get_object_or_404(available, pk=request.POST.get("plan"))
        today = timezone.localdate()
        if plan.monthly_price > 0:
            # Subscription billing is simulated like card payments; swap in a real provider here.
            SubscriptionPayment.objects.create(
                partner=partner,
                plan=plan,
                amount=plan.monthly_price,
                reference=f"SUB-{partner.pk}-{today:%Y%m%d}",
                period_end=today + timedelta(days=30),
            )
        partner.plan = plan
        partner.plan_active_until = today + timedelta(days=30) if plan.monthly_price > 0 else None
        partner.save(update_fields=["plan", "plan_active_until"])
        audit(request.user, "partner.plan_changed", partner, plan.name, request)
        messages.success(request, f"You are on the {plan.name} plan.")
        return redirect("partner:plans")
    return render(
        request,
        "dashboard/partner_plans.html",
        {"plans": available, "partner": partner, "payments": partner.subscription_payments.select_related("plan")[:12]},
    )
