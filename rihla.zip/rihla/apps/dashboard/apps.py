from django.apps import AppConfig


class DashboardConfig(AppConfig):
    name = "apps.dashboard"
    verbose_name = "Partner portal and admin dashboard"
