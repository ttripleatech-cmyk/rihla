from django import forms
from django.conf import settings
from django.contrib.auth import password_validation

from .models import Partner, PartnerDocument, User

ALLOWED_UPLOADS = (".jpg", ".jpeg", ".png", ".pdf", ".webp")


def validate_upload(f):
    name = f.name.lower()
    if not name.endswith(ALLOWED_UPLOADS):
        raise forms.ValidationError("Upload a JPG, PNG, WEBP or PDF file.")
    if f.size > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise forms.ValidationError(f"Files must be smaller than {settings.MAX_UPLOAD_MB} MB.")
    return f


class RegisterForm(forms.ModelForm):
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}))
    password2 = forms.CharField(label="Confirm password", widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}))

    class Meta:
        model = User
        fields = ["first_name", "last_name", "email", "phone"]

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists. Try logging in.")
        return email

    def clean(self):
        data = super().clean()
        p1, p2 = data.get("password1"), data.get("password2")
        if p1 and p2 and p1 != p2:
            self.add_error("password2", "The two passwords do not match.")
        elif p1:
            try:
                password_validation.validate_password(p1)
            except forms.ValidationError as exc:
                self.add_error("password1", exc)
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.username = user.email
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = [
            "first_name",
            "last_name",
            "phone",
            "date_of_birth",
            "driving_license_number",
            "license_expiry",
            "license_document",
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
            "license_expiry": forms.DateInput(attrs={"type": "date"}),
        }

    def clean_license_document(self):
        f = self.cleaned_data.get("license_document")
        if f and hasattr(f, "size"):
            validate_upload(f)
        return f


class PartnerApplyForm(forms.ModelForm):
    class Meta:
        model = Partner
        fields = ["partner_type", "name", "city", "address", "phone", "registration_number", "description"]
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}

    def clean(self):
        data = super().clean()
        if data.get("partner_type") == Partner.COMPANY and not data.get("registration_number"):
            self.add_error("registration_number", "Rental companies must enter their commercial registration number.")
        return data


class DocumentForm(forms.ModelForm):
    class Meta:
        model = PartnerDocument
        fields = ["kind", "file"]

    def clean_file(self):
        return validate_upload(self.cleaned_data["file"])
