from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import AuditLog, Partner, PartnerDocument, SubscriptionPayment, SubscriptionPlan, User


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ("email", "first_name", "last_name", "role", "email_verified", "license_verified", "is_staff")
    list_filter = ("role", "email_verified", "license_verified", "is_staff")
    search_fields = ("email", "first_name", "last_name", "phone")
    ordering = ("-date_joined",)
    add_fieldsets = DjangoUserAdmin.add_fieldsets + ((None, {"fields": ("email", "first_name", "last_name", "role")}),)
    fieldsets = DjangoUserAdmin.fieldsets + (
        (
            "Rihla profile",
            {
                "fields": (
                    "role",
                    "phone",
                    "date_of_birth",
                    "driving_license_number",
                    "license_expiry",
                    "license_verified",
                    "email_verified",
                )
            },
        ),
    )


class PartnerDocumentInline(admin.TabularInline):
    model = PartnerDocument
    extra = 0


@admin.register(Partner)
class PartnerAdmin(admin.ModelAdmin):
    list_display = ("name", "partner_type", "city", "status", "verified", "plan", "commission_override", "created_at")
    list_filter = ("status", "partner_type", "verified", "city", "plan")
    search_fields = ("name", "owner__email", "phone", "registration_number")
    inlines = [PartnerDocumentInline]


@admin.register(SubscriptionPlan)
class SubscriptionPlanAdmin(admin.ModelAdmin):
    list_display = ("name", "audience", "monthly_price", "commission_percent", "max_vehicles", "is_active", "sort_order")
    list_editable = ("is_active", "sort_order")


@admin.register(SubscriptionPayment)
class SubscriptionPaymentAdmin(admin.ModelAdmin):
    list_display = ("partner", "plan", "amount", "period_end", "paid_at")
    date_hierarchy = "paid_at"


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    """Read-only: the audit trail must not be editable from the admin."""

    list_display = ("created_at", "action", "user", "object_type", "object_id", "ip")
    list_filter = ("action",)
    search_fields = ("action", "detail", "object_id", "user__email")
    date_hierarchy = "created_at"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
