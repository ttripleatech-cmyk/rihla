import mimetypes

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.core.exceptions import PermissionDenied
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from apps.core.audit import audit
from apps.core.notify import notify

from .forms import PartnerApplyForm, ProfileForm, RegisterForm
from .models import Partner, PartnerDocument, User

VERIFY_SALT = "rihla-verify-email"
VERIFY_MAX_AGE = 3 * 24 * 3600


def send_verification_email(user):
    token = signing.dumps({"uid": user.pk}, salt=VERIFY_SALT)
    link = settings.SITE_URL + reverse("accounts:verify_email", args=[token])
    notify(
        user,
        "Confirm your email",
        f"Hi {user.first_name or 'there'},\n\nPlease confirm your email address to finish setting up your account:\n{link}\n\n"
        "The link works for 3 days.\n\nRihla Car Rental",
    )


def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user, backend="django.contrib.auth.backends.ModelBackend")
        send_verification_email(user)
        audit(user, "account.registered", user, request=request)
        messages.success(request, "Welcome to Rihla. We sent a confirmation link to your email.")
        return redirect(request.GET.get("next") or "home")
    return render(request, "accounts/register.html", {"form": form})


def verify_email(request, token):
    try:
        data = signing.loads(token, salt=VERIFY_SALT, max_age=VERIFY_MAX_AGE)
        user = User.objects.get(pk=data["uid"])
    except (signing.BadSignature, User.DoesNotExist, KeyError):
        messages.error(request, "This confirmation link is invalid or has expired. Request a new one from your profile.")
        return redirect("home")
    user.email_verified = True
    user.save(update_fields=["email_verified"])
    audit(user, "account.email_verified", user, request=request)
    messages.success(request, "Email confirmed. Thank you.")
    return redirect("home")


@login_required
@require_POST
def resend_verification(request):
    if request.user.email_verified:
        messages.info(request, "Your email is already confirmed.")
    else:
        send_verification_email(request.user)
        messages.success(request, "Confirmation link sent.")
    return redirect("accounts:profile")


@login_required
def profile(request):
    form = ProfileForm(request.POST or None, request.FILES or None, instance=request.user)
    if request.method == "POST" and form.is_valid():
        user = form.save(commit=False)
        if "license_document" in form.changed_data:
            user.license_verified = False  # a new document must be re-checked
            audit(request.user, "license.uploaded", user, request=request)
        user.save()
        messages.success(request, "Profile saved.")
        return redirect("accounts:profile")
    return render(request, "accounts/profile.html", {"form": form})


@login_required
def partner_apply(request):
    if request.user.partner_profile is not None:
        return redirect("partner:home")
    form = PartnerApplyForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        partner = form.save(commit=False)
        partner.owner = request.user
        partner.save()
        request.user.role = User.PARTNER
        request.user.save(update_fields=["role"])
        audit(request.user, "partner.applied", partner, request=request)
        messages.success(request, "Application received. Upload your documents so we can approve you faster.")
        return redirect("partner:documents")
    return render(request, "accounts/partner_apply.html", {"form": form})


@login_required
def secure_file(request, kind, pk):
    """Serve private uploads after checking who is asking. Every non-owner access is audited."""
    user = request.user
    if kind == "license":
        owner = get_object_or_404(User, pk=pk)
        file = owner.license_document
        allowed = user.pk == owner.pk or user.is_staff
        if not allowed and user.partner_profile is not None:
            # A partner may see a licence only for customers with a live booking on their vehicles.
            from apps.bookings.models import Booking

            allowed = Booking.objects.filter(
                partner=user.partner_profile,
                customer=owner,
                status__in=[Booking.CONFIRMED, Booking.ACTIVE],
            ).exists()
        obj = owner
    elif kind == "partner-doc":
        doc = get_object_or_404(PartnerDocument.objects.select_related("partner"), pk=pk)
        file = doc.file
        allowed = user.is_staff or doc.partner.owner_id == user.pk
        obj = doc
    else:
        raise Http404
    if not allowed:
        raise PermissionDenied
    if not file:
        raise Http404
    if obj.pk != getattr(user, "pk", None) and not (kind == "partner-doc" and obj.partner.owner_id == user.pk):
        audit(user, f"file.viewed.{kind}", obj, request=request)
    content_type = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
    response = FileResponse(file.open("rb"), content_type=content_type)
    response["Cache-Control"] = "private, no-store"
    response["X-Content-Type-Options"] = "nosniff"
    return response
