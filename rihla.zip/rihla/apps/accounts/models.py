from decimal import Decimal

from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.text import slugify

from apps.core.storage import private_storage


class User(AbstractUser):
    """Customers, partners and staff share one table. Staff use is_staff / is_superuser."""

    CUSTOMER, PARTNER = "customer", "partner"
    ROLE_CHOICES = [(CUSTOMER, "Customer"), (PARTNER, "Rental partner")]

    email = models.EmailField("email address", unique=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=CUSTOMER)
    phone = models.CharField(max_length=30, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    driving_license_number = models.CharField(max_length=60, blank=True)
    license_expiry = models.DateField(null=True, blank=True)
    license_document = models.FileField(upload_to="licenses/%Y/%m/", storage=private_storage, blank=True)
    license_verified = models.BooleanField(default=False)
    email_verified = models.BooleanField(default=False)

    @property
    def partner_profile(self):
        """The user's Partner record, or None."""
        try:
            return self.partner
        except Partner.DoesNotExist:
            return None

    @property
    def display_name(self):
        return self.get_full_name() or self.email


class SubscriptionPlan(models.Model):
    """What a partner pays monthly, and the commission rate that comes with it."""

    ANY, COMPANY, INDIVIDUAL = "any", "company", "individual"
    AUDIENCE_CHOICES = [(ANY, "Anyone"), (COMPANY, "Rental companies"), (INDIVIDUAL, "Individual owners")]

    name = models.CharField(max_length=60)
    audience = models.CharField(max_length=20, choices=AUDIENCE_CHOICES, default=ANY)
    monthly_price = models.DecimalField(max_digits=8, decimal_places=2, default=Decimal("0.00"), help_text="USD")
    commission_percent = models.DecimalField(max_digits=5, decimal_places=2, help_text="Platform commission on each booking")
    max_vehicles = models.PositiveIntegerField(null=True, blank=True, help_text="Leave empty for unlimited")
    featured_listings = models.BooleanField(default=False, help_text="Vehicles rank higher in search")
    description = models.CharField(max_length=200, blank=True)
    is_active = models.BooleanField(default=True)
    sort_order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "monthly_price"]

    def __str__(self):
        return f"{self.name} (${self.monthly_price}/mo, {self.commission_percent}%)"


class Partner(models.Model):
    COMPANY, INDIVIDUAL = "company", "individual"
    TYPE_CHOICES = [(COMPANY, "Rental company"), (INDIVIDUAL, "Individual car owner")]
    PENDING, APPROVED, REJECTED, SUSPENDED = "pending", "approved", "rejected", "suspended"
    STATUS_CHOICES = [
        (PENDING, "Pending review"),
        (APPROVED, "Approved"),
        (REJECTED, "Rejected"),
        (SUSPENDED, "Suspended"),
    ]

    owner = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="partner")
    partner_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=INDIVIDUAL)
    name = models.CharField("business or display name", max_length=120)
    slug = models.SlugField(unique=True, blank=True)
    city = models.ForeignKey("core.City", on_delete=models.PROTECT, related_name="partners")
    address = models.CharField(max_length=200, blank=True)
    phone = models.CharField(max_length=30)
    description = models.TextField(blank=True)
    registration_number = models.CharField("commercial registration no.", max_length=60, blank=True)
    logo = models.ImageField(upload_to="partners/", blank=True)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING, db_index=True)
    verified = models.BooleanField(default=False, help_text="Shows the verified badge once documents are checked")
    review_note = models.CharField(max_length=300, blank=True)

    plan = models.ForeignKey(SubscriptionPlan, null=True, blank=True, on_delete=models.SET_NULL, related_name="partners")
    plan_active_until = models.DateField(null=True, blank=True)
    commission_override = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True, help_text="Negotiated rate; beats the plan rate"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.name) or "partner"
            slug, n = base, 2
            while Partner.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base}-{n}"
                n += 1
            self.slug = slug
        super().save(*args, **kwargs)

    @property
    def is_approved(self):
        return self.status == self.APPROVED

    @property
    def is_company(self):
        return self.partner_type == self.COMPANY

    def effective_commission(self):
        if self.commission_override is not None:
            return self.commission_override
        if self.plan_id:
            return self.plan.commission_percent
        return settings.DEFAULT_COMMISSION_PERCENT

    def vehicle_limit(self):
        """None means unlimited. Partners without a plan get a small free allowance."""
        if self.plan_id:
            return self.plan.max_vehicles
        return 2

    def can_add_vehicle(self):
        limit = self.vehicle_limit()
        return limit is None or self.vehicles.count() < limit


class PartnerDocument(models.Model):
    COMMERCIAL_REGISTRATION, ID_CARD, VEHICLE_REGISTRATION, INSURANCE, OTHER = (
        "commercial_registration",
        "id_card",
        "vehicle_registration",
        "insurance",
        "other",
    )
    KIND_CHOICES = [
        (COMMERCIAL_REGISTRATION, "Commercial registration"),
        (ID_CARD, "National ID or passport"),
        (VEHICLE_REGISTRATION, "Vehicle registration (mechanic card)"),
        (INSURANCE, "Insurance certificate"),
        (OTHER, "Other"),
    ]
    PENDING, APPROVED, REJECTED = "pending", "approved", "rejected"
    STATUS_CHOICES = [(PENDING, "Pending"), (APPROVED, "Approved"), (REJECTED, "Rejected")]

    partner = models.ForeignKey(Partner, on_delete=models.CASCADE, related_name="documents")
    kind = models.CharField(max_length=40, choices=KIND_CHOICES)
    file = models.FileField(upload_to="partner_documents/%Y/%m/", storage=private_storage)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    note = models.CharField(max_length=200, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-uploaded_at"]

    def __str__(self):
        return f"{self.partner} - {self.get_kind_display()}"


class SubscriptionPayment(models.Model):
    partner = models.ForeignKey(Partner, on_delete=models.CASCADE, related_name="subscription_payments")
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.PROTECT, related_name="payments")
    amount = models.DecimalField(max_digits=8, decimal_places=2)
    reference = models.CharField(max_length=40)
    period_end = models.DateField()
    paid_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-paid_at"]

    def __str__(self):
        return f"{self.partner} {self.plan.name} ${self.amount}"


class AuditLog(models.Model):
    """Append-only trail of sensitive actions (approvals, cancellations, document access)."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    action = models.CharField(max_length=80, db_index=True)
    object_type = models.CharField(max_length=60, blank=True)
    object_id = models.CharField(max_length=40, blank=True)
    detail = models.TextField(blank=True)
    ip = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.created_at:%Y-%m-%d %H:%M} {self.action}"
