from django.urls import include, path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("vehicles", views.VehicleViewSet, basename="vehicle")
router.register("bookings", views.BookingViewSet, basename="booking")

urlpatterns = [
    path("v1/cities/", views.CityListView.as_view(), name="api-cities"),
    path("v1/auth/token/", obtain_auth_token, name="api-token"),
    path("v1/", include(router.urls)),
    path("schema/", SpectacularAPIView.as_view(), name="api-schema"),
    path("docs/", SpectacularSwaggerView.as_view(url_name="api-schema"), name="api-docs"),
]
