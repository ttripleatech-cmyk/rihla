from django.conf import settings
from rest_framework import serializers

from apps.bookings.models import Booking, Payment
from apps.core.models import City
from apps.fleet.models import Vehicle


class CitySerializer(serializers.ModelSerializer):
    country = serializers.CharField(source="country.name")

    class Meta:
        model = City
        fields = ["id", "name", "slug", "country", "latitude", "longitude"]


class VehicleSerializer(serializers.ModelSerializer):
    title = serializers.CharField(read_only=True)
    city = serializers.CharField(source="city.name")
    city_slug = serializers.CharField(source="city.slug")
    partner = serializers.CharField(source="partner.name")
    partner_type = serializers.CharField(source="partner.partner_type")
    partner_verified = serializers.BooleanField(source="partner.verified")
    avg_rating = serializers.FloatField(read_only=True, allow_null=True)
    review_count = serializers.IntegerField(read_only=True)
    photos = serializers.SerializerMethodField()
    features = serializers.ListField(source="features_list", child=serializers.CharField(), read_only=True)

    class Meta:
        model = Vehicle
        fields = [
            "id", "title", "make", "model", "year", "category", "transmission", "fuel", "seats", "doors", "bags",
            "air_conditioning", "color", "features", "description",
            "daily_price", "weekly_price", "monthly_price", "deposit",
            "mileage_limit_per_day", "extra_km_fee", "insurance_included", "insurance_details",
            "min_driver_age", "min_license_years", "rental_conditions",
            "delivery_available", "delivery_fee", "pay_at_pickup", "booking_mode", "cancellation_policy",
            "city", "city_slug", "partner", "partner_type", "partner_verified",
            "avg_rating", "review_count", "photos",
        ]

    def get_photos(self, obj):
        request = self.context.get("request")
        urls = []
        for photo in obj.photos.all():
            url = photo.image.url
            urls.append(request.build_absolute_uri(url) if request else url)
        return urls


class BookingSerializer(serializers.ModelSerializer):
    vehicle_title = serializers.CharField(source="vehicle.title", read_only=True)
    status_label = serializers.CharField(source="get_status_display", read_only=True)
    amount_paid = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        model = Booking
        fields = [
            "reference", "vehicle", "vehicle_title", "mode", "status", "status_label",
            "start_at", "end_at", "days", "driver_name", "driver_phone", "extras",
            "delivery_requested", "delivery_address",
            "base_amount", "extras_amount", "delivery_fee", "discount_amount", "subtotal", "vat_amount",
            "total", "deposit", "amount_paid", "refund_amount", "hold_expires_at", "created_at",
        ]
        read_only_fields = fields


class BookingCreateSerializer(serializers.Serializer):
    vehicle = serializers.PrimaryKeyRelatedField(queryset=Vehicle.objects.filter(status=Vehicle.ACTIVE))
    start_at = serializers.DateTimeField()
    end_at = serializers.DateTimeField()
    extras = serializers.ListField(child=serializers.ChoiceField(choices=list(settings.EXTRAS)), required=False, default=list)
    delivery = serializers.BooleanField(required=False, default=False)
    delivery_address = serializers.CharField(required=False, allow_blank=True, default="")
    promo_code = serializers.CharField(required=False, allow_blank=True, default="")
    driver_name = serializers.CharField(max_length=120)
    driver_phone = serializers.CharField(max_length=30)
    notes = serializers.CharField(required=False, allow_blank=True, default="")


class PaySerializer(serializers.Serializer):
    method = serializers.ChoiceField(choices=[Payment.CARD, Payment.CASH])
    card_number = serializers.CharField(required=False, allow_blank=True, default="", write_only=True)
    holder = serializers.CharField(required=False, allow_blank=True, default="")
