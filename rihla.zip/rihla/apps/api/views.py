from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework import mixins, permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.generics import ListAPIView
from rest_framework.response import Response

from apps.bookings import services
from apps.bookings.models import Booking
from apps.bookings.services import BookingError
from apps.core.models import City
from apps.core.utils import parse_dt
from apps.fleet.search import search_vehicles

from .serializers import (
    BookingCreateSerializer,
    BookingSerializer,
    CitySerializer,
    PaySerializer,
    VehicleSerializer,
)

SEARCH_PARAMS = [
    OpenApiParameter(name, str, required=False)
    for name in (
        "city", "start", "end", "category", "transmission", "fuel", "make", "seats",
        "min_price", "max_price", "instant", "partner_type", "q", "sort",
    )
]


class CityListView(ListAPIView):
    queryset = City.objects.filter(country__is_active=True).select_related("country")
    serializer_class = CitySerializer
    pagination_class = None
    permission_classes = [permissions.AllowAny]


@extend_schema(parameters=SEARCH_PARAMS)
class VehicleViewSet(viewsets.ReadOnlyModelViewSet):
    """Search live vehicles. Pass `start` and `end` (ISO 8601) to hide unavailable cars."""

    serializer_class = VehicleSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = []

    def get_queryset(self):
        return search_vehicles(self.request.query_params)

    @extend_schema(
        parameters=[
            OpenApiParameter("start", str, required=True),
            OpenApiParameter("end", str, required=True),
            OpenApiParameter("extras", str, many=True, required=False),
            OpenApiParameter("delivery", bool, required=False),
            OpenApiParameter("promo", str, required=False),
        ],
        responses={200: OpenApiTypes.OBJECT},
    )
    @action(detail=True, methods=["get"])
    def quote(self, request, pk=None):
        vehicle = self.get_object()
        start, end = parse_dt(request.query_params.get("start")), parse_dt(request.query_params.get("end"))
        if not start or not end or end <= start:
            raise ValidationError("Provide valid start and end, with end after start.")
        priced = services.quote(
            vehicle, start, end, request.query_params.getlist("extras"),
            request.query_params.get("delivery") in ("1", "true"), request.query_params.get("promo", ""),
        )
        data = services.quote_to_json(priced)
        data["available"] = services.is_available(vehicle, start, end)
        return Response(data)


class BookingViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    """The signed-in customer's bookings."""

    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]
    lookup_field = "reference"
    filter_backends = []

    def get_queryset(self):
        services.expire_stale()
        return Booking.objects.filter(customer=self.request.user).select_related("vehicle")

    @extend_schema(request=BookingCreateSerializer, responses={201: BookingSerializer})
    def create(self, request):
        serializer = BookingCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        try:
            booking = services.create_booking(
                customer=request.user, vehicle=d["vehicle"], start=d["start_at"], end=d["end_at"],
                extras=d["extras"], delivery=d["delivery"], delivery_address=d["delivery_address"],
                promo_code=d["promo_code"], driver_name=d["driver_name"], driver_phone=d["driver_phone"], notes=d["notes"],
            )
        except BookingError as exc:
            raise ValidationError(str(exc))
        return Response(BookingSerializer(booking).data, status=status.HTTP_201_CREATED)

    @extend_schema(request=PaySerializer, responses={200: BookingSerializer})
    @action(detail=True, methods=["post"])
    def pay(self, request, reference=None):
        booking = self.get_object()
        serializer = PaySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            booking = services.pay_booking(
                booking, method=serializer.validated_data["method"],
                card_number=serializer.validated_data["card_number"], holder=serializer.validated_data["holder"],
            )
        except BookingError as exc:
            raise ValidationError(str(exc))
        return Response(BookingSerializer(booking).data)

    @extend_schema(request=None, responses={200: BookingSerializer})
    @action(detail=True, methods=["post"])
    def cancel(self, request, reference=None):
        booking = self.get_object()
        try:
            booking = services.cancel_booking(booking, request.user, request.data.get("reason", ""))
        except BookingError as exc:
            raise ValidationError(str(exc))
        return Response(BookingSerializer(booking).data)
