/* Rihla Car Rental - small progressive enhancements. The site works without JavaScript. */
(function () {
  "use strict";

  var money = function (value) {
    return "$" + Number(value).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Ask before destructive actions: <form data-confirm="Cancel this booking?">
  document.addEventListener("submit", function (event) {
    var message = event.target.getAttribute("data-confirm");
    if (message && !window.confirm(message)) {
      event.preventDefault();
    }
  });

  // Keep the return time after the pickup time.
  var pickup = document.querySelector("[data-pickup]");
  var dropoff = document.querySelector("[data-dropoff]");
  if (pickup && dropoff) {
    pickup.addEventListener("change", function () {
      dropoff.min = pickup.value;
      if (dropoff.value && dropoff.value <= pickup.value) {
        dropoff.value = "";
      }
    });
  }

  // Live price quote on the vehicle page.
  var form = document.getElementById("booking-form");
  var box = document.getElementById("quote-box");
  if (form && box) {
    var timer = null;
    var render = function (q) {
      if (q.error) {
        box.innerHTML = '<p class="muted small">' + q.error + "</p>";
        return;
      }
      var rows = "";
      rows += "<tr><td>" + q.days + " day" + (q.days > 1 ? "s" : "") + " rental</td><td>" + money(q.base) + "</td></tr>";
      if (Number(q.extras_total) > 0) rows += "<tr><td>Extras</td><td>" + money(q.extras_total) + "</td></tr>";
      if (Number(q.delivery_fee) > 0) rows += "<tr><td>Delivery</td><td>" + money(q.delivery_fee) + "</td></tr>";
      if (Number(q.discount) > 0) rows += "<tr><td>Promo " + (q.promo || "") + "</td><td>-" + money(q.discount) + "</td></tr>";
      if (Number(q.vat) > 0) rows += "<tr><td>VAT " + Number(q.vat_rate) + "%</td><td>" + money(q.vat) + "</td></tr>";
      rows += '<tr class="total"><td>Total</td><td>' + money(q.total) + "</td></tr>";
      if (Number(q.deposit) > 0) rows += '<tr class="minor"><td>Deposit held at pickup</td><td>' + money(q.deposit) + "</td></tr>";
      var html = '<table class="quote-table">' + rows + "</table>";
      if (q.promo_error) html += '<p class="small" style="color:#b3372d;margin-top:8px">' + q.promo_error + "</p>";
      if (!q.available) html += '<p class="small" style="color:#b3372d;margin-top:8px"><b>Not available for these dates.</b> Try other dates.</p>';
      box.innerHTML = html;
      var go = document.getElementById("continue-btn");
      if (go) go.disabled = !q.available;
    };
    var refresh = function () {
      var data = new FormData(form);
      var params = new URLSearchParams();
      data.forEach(function (value, key) {
        if (key !== "csrfmiddlewaretoken") params.append(key, value);
      });
      if (!params.get("start") || !params.get("end")) {
        box.innerHTML = '<p class="muted small">Choose pickup and return times to see the price.</p>';
        return;
      }
      params.set("vehicle", form.getAttribute("data-vehicle"));
      fetch(form.getAttribute("data-quote-url") + "?" + params.toString(), { headers: { Accept: "application/json" } })
        .then(function (r) { return r.json(); })
        .then(render)
        .catch(function () {
          box.innerHTML = '<p class="muted small">Could not load the price. Press Continue to see it.</p>';
        });
    };
    form.addEventListener("input", function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(refresh, 250);
    });
    refresh();
  }

  // Photo gallery: click a thumbnail to swap the main image.
  document.querySelectorAll("[data-thumb]").forEach(function (thumb) {
    thumb.addEventListener("click", function () {
      var main = document.getElementById("main-photo");
      if (main) main.src = thumb.getAttribute("data-thumb");
    });
  });

  // Map view of search results (Leaflet + OpenStreetMap, no API key needed).
  var mapEl = document.getElementById("map");
  var pointsEl = document.getElementById("map-points");
  if (mapEl && pointsEl && window.L) {
    var points = JSON.parse(pointsEl.textContent || "[]");
    var map = window.L.map(mapEl).setView([33.89, 35.5], 9);
    window.L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 18,
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(map);
    var bounds = [];
    points.forEach(function (p) {
      var marker = window.L.marker([p.lat, p.lng]).addTo(map);
      marker.bindPopup('<b>' + p.title + '</b><br>' + money(p.price) + ' / day<br><a href="/cars/' + p.id + '/">View car</a>');
      bounds.push([p.lat, p.lng]);
    });
    if (bounds.length) map.fitBounds(bounds, { padding: [40, 40], maxZoom: 12 });
  }
})();
