#!/usr/bin/env bash
# Build step on the hosting platform: install dependencies and collect static files.
set -o errexit
pip install -r requirements.txt
python manage.py collectstatic --noinput
