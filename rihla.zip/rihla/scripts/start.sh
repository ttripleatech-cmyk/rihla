#!/usr/bin/env bash
# Start step on the hosting platform: prepare the database, then run the web server.
set -o errexit

APPS="core accounts fleet bookings"
PERSIST_DIR="${PERSIST_DIR:-/var/data}"

# --- Migrations -------------------------------------------------------------------
# Best practice: run `python manage.py makemigrations` once on your computer and commit
# the files. Until you do, AUTO_MIGRATIONS=disk generates them on the server and keeps
# them on the persistent disk so they survive redeploys and never drift from the database.
if [ "${AUTO_MIGRATIONS:-}" = "disk" ]; then
  BACKUP="$PERSIST_DIR/migrations"
  for app in $APPS; do
    if [ -d "$BACKUP/$app" ] && [ ! -f "apps/$app/migrations/0001_initial.py" ]; then
      mkdir -p "apps/$app/migrations"
      cp "$BACKUP/$app/"*.py "apps/$app/migrations/"
    fi
  done
  python manage.py makemigrations $APPS --noinput
  for app in $APPS; do
    mkdir -p "$BACKUP/$app"
    cp "apps/$app/migrations/"*.py "$BACKUP/$app/"
  done
fi
python manage.py migrate --noinput

# --- First-run helpers --------------------------------------------------------------
# Create the owner login from environment variables (skipped if it already exists).
if [ -n "${DJANGO_SUPERUSER_EMAIL:-}" ] && [ -n "${DJANGO_SUPERUSER_PASSWORD:-}" ]; then
  export DJANGO_SUPERUSER_USERNAME="${DJANGO_SUPERUSER_USERNAME:-$DJANGO_SUPERUSER_EMAIL}"
  python manage.py createsuperuser --noinput || echo "Superuser already exists, skipping."
fi
# Load demo data once, only into an empty database (the command refuses otherwise).
if [ "${SEED_DEMO:-}" = "true" ]; then
  python manage.py seed_demo || echo "Demo data not loaded (database is not empty)."
fi

exec gunicorn config.wsgi:application \
  --bind "0.0.0.0:${PORT:-8000}" \
  --workers "${WEB_CONCURRENCY:-3}" \
  --access-logfile -
