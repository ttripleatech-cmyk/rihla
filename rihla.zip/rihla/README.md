# Rihla Car Rental

A multi-vendor car rental marketplace for Lebanon, built to expand to other countries.
Rental companies and individual owners list cars; customers search, compare and book;
the platform earns commission and provider subscriptions.

> **Status: written but not yet executed.** The environment this project was built in could not
> install Django, so the code has been syntax-checked and cross-checked (URL names, template
> structure, model dependencies) but **never run against Django**. Expect to fix a few small
> issues on first run. Section 3 gives the exact first-run steps, and `python manage.py test`
> (38 tests) tells you quickly what, if anything, needs attention.

---

## 1. Architecture

| Layer | Choice | Why |
|---|---|---|
| Backend | Python 3.12, Django 5.2 LTS | Auth, permissions, ORM, migrations and an admin site out of the box |
| API | Django REST Framework + drf-spectacular | Same booking engine exposed as JSON at `/api/v1/`, OpenAPI docs at `/api/docs/` |
| Frontend | Server-rendered Django templates, custom CSS, small vanilla JS | One codebase to ship first; works without JavaScript; fast on mobile |
| Database | PostgreSQL (SQLite for local dev) | Row locking and an exclusion constraint make double-booking impossible |
| Cache / queue | Redis + Celery | Hold expiry, e-mails, pickup reminders run in the background |
| Files | Public media (vehicle photos) and a **private** store (licences, partner documents) | Private files are never mapped to a URL; they pass a permission check first |
| Payments | Gateway interface + simulated gateway | Swap in a real provider without touching booking code |
| Deploy | Docker, gunicorn, WhiteNoise, HTTPS at the proxy | `docker compose up` runs web, worker, scheduler, PostgreSQL and Redis |

**Why not Next.js yet?** A second codebase and build pipeline would slow the first usable
product. Because every feature is already available as `/api/v1/`, a Next.js or mobile app can
replace the templates later without changing the backend.

### Apps

```
apps/core        countries, cities, promo codes, helpers, background tasks, home pages
apps/accounts    users, partners, plans, documents, subscription payments, audit log
apps/fleet       vehicles, photos, blocked dates, tiered pricing, search
apps/bookings    bookings, payments, reviews, complaints, the booking engine (services.py)
apps/dashboard   partner portal (/partner/) and admin dashboard (/manage/)
apps/api         REST API (/api/v1/)
```

Dependencies flow one way: `core -> accounts -> fleet -> bookings`.

### Database schema (main tables)

- **Country** (code, currency, vat_rate) 1-n **City** (slug, lat/lng). New market = new rows.
- **User** (email login, role, phone, licence document, verification flags).
- **SubscriptionPlan** (audience, monthly price, commission %, vehicle limit, featured).
- **Partner** (1-1 User; company or individual; status pending/approved/rejected/suspended;
  verified badge; plan; optional negotiated `commission_override`) 1-n **PartnerDocument**.
- **Vehicle** (partner, city, specs, daily/weekly/monthly price, deposit, mileage, insurance,
  delivery, `booking_mode` instant/request, cancellation policy, status) 1-n **VehiclePhoto**,
  **BlockedPeriod**.
- **Booking** (reference `RIH-XXXXXXXX`, vehicle, partner, customer, dates, status, and the full
  money breakdown frozen at booking time: base, extras, delivery, discount, VAT, total, deposit,
  commission rate and amount, partner payout) 1-n **Payment** (charge/refund); 1-1 **Review**;
  1-n **Complaint**.
- **PromoCode**, **AuditLog** (append-only), **SubscriptionPayment**.

## 2. How the booking engine works (`apps/bookings/services.py`)

- **Instant vehicles:** booking is held for 15 minutes (`pending_payment`), then paid and `confirmed`.
- **Request vehicles:** request is sent (`requested`, owner has 24 h). If accepted, the customer
  has 24 h to pay. Accepting automatically declines other overlapping requests. Requests do not
  block dates until accepted.
- **Double-booking prevention:** every write locks the vehicle row, expires stale holds and
  re-checks availability in one transaction. On PostgreSQL an exclusion constraint
  (`booking_no_overlap`, created after `migrate`) rejects overlapping live bookings even if
  application code is bypassed.
- **Pricing:** cheapest combination of monthly, weekly and daily rates, plus extras and delivery,
  minus promo, plus the country's VAT. The deposit is shown separately and held by the owner at pickup.
- **Commission:** partner override, else plan rate, else the default. Frozen on each booking.
- **Cancellation:** flexible / moderate / strict policies decide the refund when a customer
  cancels. Owner cancellations always refund in full. Cash bookings collect at pickup.
- **Audit trail:** approvals, cancellations, plan changes and every non-owner view of a private
  document are recorded.

## 3. Run it locally (SQLite, no Docker)

```bash
cd rihla
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # optional for local use

# Migrations are generated on first run (see "Known gaps"):
python manage.py makemigrations core accounts fleet bookings
python manage.py migrate
python manage.py seed_demo      # Lebanon, plans, partners, 14 cars, trips, reviews
python manage.py runserver
```

Open http://127.0.0.1:8000. Demo logins (local password `Rihla#Demo2026`; on a live site it is random and printed in the log):

| Account | Use it to |
|---|---|
| `admin@rihla.test` | Open `/manage/` (dashboard) and `/admin/` (all data) |
| `cedar@rihla.test` | Partner portal for a rental company, with an open booking request |
| `karim@rihla.test` | Partner portal for an individual owner |
| `byblos@rihla.test` | A pending partner waiting for admin approval |
| `layla@rihla.test` | A customer with an upcoming booking |

Promo codes: `WELCOME10`, `RIHLA20`. Test card: any number works; numbers ending in `0002` are declined.
E-mails print to the terminal.

Run the tests: `python manage.py test`

## 4. Run with Docker (PostgreSQL + Redis + Celery)

```bash
cp .env.example .env
docker compose up --build -d
docker compose exec web python manage.py makemigrations core accounts fleet bookings   # first run only
docker compose exec web python manage.py migrate
docker compose exec web python manage.py seed_demo
```

## 4b. Put it online (Render, about 15 minutes)

The repo includes `render.yaml`, `scripts/build.sh` and `scripts/start.sh`, so Render can create
the web service and the PostgreSQL database from one file.

1. Put the `rihla` folder in a GitHub repository (create a free account, make a new private repository, upload the files).
2. Create an account at https://render.com and choose **New > Blueprint**. Connect the repository.
3. Render reads `render.yaml` and asks for two values: `DJANGO_SUPERUSER_EMAIL` and
   `DJANGO_SUPERUSER_PASSWORD`. These become your owner login for `/manage/` and `/admin/`.
4. Click **Apply**. The first build takes a few minutes. Your site opens at the `onrender.com` address Render shows.
5. Open the service **Logs**. The first start prints the demo accounts and a random demo password.

What the start script does for you: generates the database migrations (and stores them on the
persistent disk so they never drift), migrates the database, creates your owner login, and loads
the demo data once (`SEED_DEMO=true`).

**Before real customers use it:**
- Set `SEED_DEMO` to `false` and delete the demo users and demo cars in `/admin/`. The demo accounts are for evaluation only.
- Run `python manage.py makemigrations` once on a computer and commit the files, then remove `AUTO_MIGRATIONS` from the environment.
- Connect your own domain in the Render dashboard (HTTPS is automatic).
- Add real e-mail settings (`EMAIL_BACKEND`, `EMAIL_HOST`, ...). Until then e-mails only appear in the logs.
- Plans, prices and disk size in `render.yaml` use Render's defaults. Check current pricing; a disk and a database are paid features.
- Photos are served by Django from the persistent disk, which is fine for a small site. Move to S3-compatible storage with a CDN as you grow.
- Background jobs run inline (`CELERY_EAGER=true`), so pickup-reminder e-mails are not sent until you add a Render background worker running `celery -A config worker` and `celery -A config beat` plus Redis.
- Payments are still simulated. See section 6.

## 5. What is where

| URL | What |
|---|---|
| `/` `/cars/` `/cars/<id>/` | Marketplace: search, filters, map, vehicle page with live price |
| `/bookings/` | Customer trips, payment, cancellation, receipts, reviews, complaints |
| `/partner/` | Partner portal: requests, bookings, fleet, photos, blocked dates, documents, plan |
| `/manage/` | Admin dashboard: revenue, commission, approvals, bookings, complaints, audit log, CSV export |
| `/admin/` | Django admin for everything else: promo codes, plans, commission rates, countries, cities |
| `/api/v1/`, `/api/docs/` | REST API and Swagger docs |

## 6. Going to production checklist

1. `DEBUG=false`, a real `SECRET_KEY`, `ALLOWED_HOSTS`, `CSRF_TRUSTED_ORIGINS`, HTTPS in front.
2. `DATABASE_URL` to managed PostgreSQL with daily backups; `REDIS_URL`; `CELERY_EAGER=false`; run worker and beat.
3. Real SMTP (`EMAIL_*`) and a transactional sender.
4. **Payments:** write a gateway class (subclass `BaseGateway`) for a provider that supports Lebanon
   with hosted checkout, set `PAYMENT_GATEWAY`. Card numbers must never touch your server.
   Subscription billing in `partner_views.plans` is also simulated and needs the same treatment.
5. **Storage:** point `private_storage()` in `apps/core/storage.py` and media at private/public S3-compatible buckets.
6. Have a lawyer review `/terms/` and your VAT handling; confirm the 11% rate with an accountant.
7. Monitoring (Sentry, uptime on `/healthz/`), rate limits on login, security review.

## 7. Known gaps

- **Not executed.** See the note at the top.
- **No migration files** are included, because they must be generated by Django. Run `makemigrations` once and commit the result.
- Card and subscription payments are simulated. Maps use Leaflet with OpenStreetMap (no key).
- One site-wide time zone (`TIME_ZONE`); per-country time zones are the next step for expansion.
- English only; the model and templates are ready for Django translations (Arabic and French next, with right-to-left CSS).
- Not yet built: partner payout statements, dispute workflow beyond complaints, SMS/WhatsApp notifications, identity verification service.

## 8. Roadmap against your phases

1. Core marketplace: **done** (homepage, accounts, listings, search, filters, details).
2. Booking engine: **done** (availability, conflict prevention, pricing, cancellations).
3. Multi-vendor: **done** (partner applications, approval, fleet, commission rules, dashboards).
4. Payments and automation: **partly** (e-mails, reminders, expiry jobs done; real payment provider to add).
5. Production launch: **checklist above**.

## 9. Brand

**Rihla Car Rental**: "rihla" is Arabic for journey. Colours: sea ink `#0B2A3C`, cedar `#1E6B52`,
saffron `#F2A93B`. The logo mark is a winding road ending in a destination dot (`static/img/`).
Check trademark and domain availability before committing to the name.
