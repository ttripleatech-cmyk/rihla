import os

from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

app = Celery("rihla")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    # Release unpaid holds and expire unanswered requests.
    "expire-stale-bookings": {"task": "apps.core.tasks.expire_holds_task", "schedule": 60.0},
    # E-mail customers about pickups happening in about a day.
    "pickup-reminders": {"task": "apps.core.tasks.pickup_reminders_task", "schedule": 900.0},
}
