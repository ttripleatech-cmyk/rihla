from django.conf import settings
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.static import serve

admin.site.site_header = "Rihla Car Rental administration"
admin.site.site_title = "Rihla admin"
admin.site.index_title = "Platform data"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("apps.core.urls")),
    path("cars/", include("apps.fleet.urls")),
    path("bookings/", include("apps.bookings.urls")),
    path("accounts/", include("apps.accounts.urls")),
    path("accounts/", include("django.contrib.auth.urls")),  # password reset / change flows
    path("partner/", include("apps.dashboard.partner_urls")),
    path("manage/", include("apps.dashboard.admin_urls")),
    path("api/", include("apps.api.urls")),
]

if settings.DEBUG or settings.SERVE_MEDIA:
    # Public media only (vehicle photos). Private documents are served by permission-checked views.
    urlpatterns += [re_path(r"^media/(?P<path>.*)$", serve, {"document_root": settings.MEDIA_ROOT})]
